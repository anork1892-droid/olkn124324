import {anchorData} from '../src/source-protocols.ts';
import {test} from 'node:test';import assert from 'node:assert/strict';import pg from 'pg';import {TARGET,WSOL,JUPITER} from '../src/core.ts';
test('monitor baseline, missed transaction recovery, quote fill, duplicate notification and RPC outage',{skip:!process.env.TEST_DATABASE_URL},async()=>{
 const admin=new pg.Pool({connectionString:process.env.TEST_DATABASE_URL});const schema='monitor_'+Date.now();await admin.query(`CREATE SCHEMA ${schema}`);
 const url=new URL(process.env.TEST_DATABASE_URL!);url.searchParams.set('options','-c search_path='+schema);process.env.DATABASE_URL=url.toString();process.env.SOLANA_RPC_URL='https://rpc.test';
 const {db,initialize}=await import('../src/store.ts');const {poll,health}=await import('../src/monitor.ts');const original=globalThis.fetch;let advanced=false,offline=false;
 globalThis.fetch=(async(input,init)=>{
  const u=new URL(String(input));assert(!u.pathname.includes('/execute'));
  if(u.hostname==='rpc.test'){
   if(offline)throw Error('RPC disconnected');const request=JSON.parse(String(init?.body));
   if(request.method==='getSignaturesForAddress')return Response.json({result:advanced?[{signature:'NEW',slot:2},{signature:'BASE',slot:1}]:[{signature:'BASE',slot:1}]});
   if(request.method==='getTransaction')return Response.json({result:{meta:{err:null,fee:5000,preTokenBalances:[{accountIndex:1,mint:WSOL,owner:TARGET,uiTokenAmount:{amount:'2000000000',decimals:9}}],postTokenBalances:[{accountIndex:1,mint:WSOL,owner:TARGET,uiTokenAmount:{amount:'1000000000',decimals:9}},{accountIndex:2,mint:'TOKEN',owner:TARGET,uiTokenAmount:{amount:'1000000',decimals:6}}]},transaction:{message:{instructions:[{programId:JUPITER,data:anchorData('route')}]}}}});
   throw Error('Unexpected RPC');
  }
  if(u.pathname==='/price/v3')return Response.json({TOKEN:{liquidity:100000},[WSOL]:{usdPrice:200}});
  if(u.pathname==='/swap/v2/order')return Response.json({inputMint:WSOL,outputMint:'TOKEN',inAmount:'100000000',outAmount:'1000000',otherAmountThreshold:'990000',priceImpact:0.1,slippageBps:100,swapMode:'ExactIn'});
  throw Error('Unexpected external request');
 }) as typeof fetch;
 try{
  await initialize();await db.query(`UPDATE config SET value=value || '{"paused":false,"executionDelayMs":0}'::jsonb`);
  await poll();assert.equal((await db.query('SELECT count(*) FROM events')).rows[0].count,'0');
  advanced=true;await poll();assert.equal((await db.query('SELECT quantity FROM positions')).rows[0].quantity,'990000');
  await poll();assert.equal((await db.query('SELECT count(*) FROM paper_orders')).rows[0].count,'1');
  offline=true;await poll();assert.equal(health.rpc,'error');assert.equal((await db.query('SELECT signature FROM cursor')).rows[0].signature,'NEW');
  offline=false;await poll();assert.equal(health.rpc,'connected');assert.equal((await db.query('SELECT count(*) FROM paper_orders')).rows[0].count,'1');
 }finally{globalThis.fetch=original;await db.end();await admin.query(`DROP SCHEMA ${schema} CASCADE`);await admin.end();}
});
