import {buySize} from './risk.ts';
import {db} from './store.ts';import {LiveAdapter} from './live.ts';import {inventory,chain} from './portfolio.ts';import {JupiterQuotes} from './jupiter.ts';import {sellAmount,WSOL,type Change} from './core.ts';
export async function liveConfiguration(){try{const adapter=await LiveAdapter.configured();return {configured:true,wallet:adapter.wallet};}catch{return {configured:false,wallet:null};}}
export async function activateLive(wallet:string,confirmation:string){
 const adapter=await LiveAdapter.configured();if(wallet!==adapter.wallet||confirmation!=='ENABLE LIVE '+wallet)throw Error('Type the exact live activation phrase for the configured dedicated wallet');
 const current=await inventory(wallet);const tracked=(await db.query("SELECT mint,quantity FROM positions WHERE mode='live' AND quantity>0")).rows;
 for(const t of current.tokens)if(BigInt(t.quantity)>0n&&!tracked.find(p=>p.mint===t.mint&&p.quantity===t.quantity))throw Error('Wallet has untracked assets or mismatched balances; use a dedicated wallet');
 for(const p of tracked)if(!current.tokens.find(t=>t.mint===p.mint&&t.quantity===p.quantity))throw Error('Recorded live holdings do not match wallet');
 const c=await db.connect();try{await c.query('BEGIN');await c.query('SELECT value FROM config WHERE id=1 FOR UPDATE');if((await c.query("SELECT 1 FROM live_orders WHERE status IN ('PREPARED','BROADCAST','UNKNOWN','AWAITING_RECONCILIATION')")).rowCount)throw Error('Unsettled live order requires reconciliation');
 await c.query("INSERT INTO balances(mode,lamports) VALUES('live',$1) ON CONFLICT(mode) DO UPDATE SET lamports=EXCLUDED.lamports",[current.lamports]);
 await c.query("UPDATE config SET value=value || $1::jsonb WHERE id=1",[JSON.stringify({mode:'live',paused:true,emergency:false,liveWallet:wallet})]);await c.query('INSERT INTO audit(message) VALUES($1)',['Live mode explicitly activated for '+wallet+'; copying remains paused']);await c.query('COMMIT');}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
}
export async function executeLive(id:string,change:Change){
 const adapter=await LiveAdapter.configured(),connection=await db.connect();
 try{if(!(await connection.query('SELECT pg_try_advisory_lock(879025) AS acquired')).rows[0].acquired)return 'WAITING';
 if((await db.query('SELECT 1 FROM live_orders WHERE id=$1',[id])).rowCount)return 'DUPLICATE';
 const skip=async(reason:string)=>{await db.query("INSERT INTO live_orders(id,status,reason) VALUES($1,'SKIPPED',$2) ON CONFLICT DO NOTHING",[id,reason]);return 'SKIPPED';};
 const s=(await db.query('SELECT value FROM config WHERE id=1')).rows[0].value;
 if(s.mode!=='live'||s.paused||s.emergency||s.liveWallet!==adapter.wallet)return await skip('Live copying is not activated');
 if((await db.query("SELECT 1 FROM live_orders WHERE status IN ('PREPARED','BROADCAST','UNKNOWN','AWAITING_RECONCILIATION')")).rowCount)return 'WAITING';
 if(s.blacklist.includes(change.mint))return await skip('Token blacklisted');
 const inv=await inventory(adapter.wallet),positions=(await db.query("SELECT * FROM positions WHERE mode='live' AND quantity>0")).rows;
 for(const t of inv.tokens)if(BigInt(t.quantity)>0n&&(!positions.find(p=>p.mint===t.mint&&p.quantity===t.quantity)||t.program!=='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'))return await skip('Trading wallet inventory differs from recorded copied positions');
 for(const p of positions)if(!inv.tokens.find(t=>t.mint===p.mint&&t.quantity===p.quantity))return await skip('Trading wallet balance reconciliation failed');
 const p=positions.find(p=>p.mint===change.mint),ours=BigInt(p?.quantity??0);
 const daily=BigInt((await db.query("SELECT COALESCE(sum((details->>'realized')::numeric),0)::text AS n FROM live_orders WHERE status IN ('CONFIRMED','FAILED') AND created>=date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'")).rows[0].n);
 if(daily<=-BigInt(s.dailyLossLamports))return await skip('Daily live realized loss limit');
 if(change.side==='SELL'&&ours===0n)return await skip('No copied live holding');
 if(change.side==='BUY'&&((ours>0n&&!s.additionalBuys)||(ours===0n&&positions.length>=s.maxPositions)))return await skip('Position policy');
 const amount=change.side==='BUY'?buySize(s,BigInt(inv.lamports),change.sourceSpent,change.sourceBalance):sellAmount(ours,change.quantity,change.before,s.sellStrategy,s.multiplierBps);if(!amount)return await skip('No eligible quantity');
 const q=await new JupiterQuotes({priorityFeeLamports:BigInt(s.priorityFeeLamports),jitoTipLamports:BigInt(s.jitoTipLamports??0),requireMarketCap:s.minMarketCapUsd!=null||s.maxMarketCapUsd!=null}).quote(change.mint,change.side,amount,s.slippageBps);
 if((s.minMarketCapUsd!=null||s.maxMarketCapUsd!=null)&&(!Number.isFinite(q.marketCapUsd)||(s.minMarketCapUsd!=null&&q.marketCapUsd!<s.minMarketCapUsd)||(s.maxMarketCapUsd!=null&&q.marketCapUsd!>s.maxMarketCapUsd)))return await skip('Market-cap filter or missing market-cap data');
 if(q.impactBps>s.maxImpactBps||q.liquiditySol<s.minLiquiditySol)return await skip('Liquidity or price-impact limit');
 if(change.side==='BUY'&&(BigInt(inv.lamports)<amount+BigInt(s.reserveLamports)+BigInt(s.maxCostLamports)||BigInt(p?.cost??0)+amount+BigInt(s.maxCostLamports)>BigInt(s.maxPerTokenLamports)))return await skip('Allocation or SOL reserve limit');
 const prepared=await adapter.prepare({wallet:adapter.wallet,inputMint:change.side==='BUY'?WSOL:change.mint,outputMint:change.side==='BUY'?change.mint:WSOL,amount,minimumOutput:q.output,maxCost:BigInt(s.maxCostLamports),priorityFee:BigInt(s.priorityFeeLamports),jitoTip:BigInt(s.jitoTipLamports??0)},s.slippageBps);
 await connection.query('BEGIN');const current=(await connection.query('SELECT value FROM config WHERE id=1 FOR UPDATE')).rows[0].value;
 if(JSON.stringify(current)!==JSON.stringify(s)||Date.now()-prepared.preparedAt>5000){await connection.query('ROLLBACK');return await skip('Control/settings changed or prepared transaction expired');}
 await connection.query("INSERT INTO live_orders(id,status,signature,prepared,details) VALUES($1,'PREPARED',$2,$3,$4)",[id,prepared.signature,JSON.stringify(prepared),JSON.stringify({change:{...change,before:String(change.before),after:String(change.after),quantity:String(change.quantity)},wallet:adapter.wallet},(_,v)=>typeof v==='bigint'?String(v):v)]);await connection.query('COMMIT');
 // Durable signature precedes network I/O. Never create a replacement transaction on an ambiguous response.
 await connection.query('BEGIN');
 const control=(await connection.query('SELECT value FROM config WHERE id=1 FOR UPDATE')).rows[0].value;
 if(control.paused||control.emergency||control.mode!=='live'){
  await connection.query("UPDATE live_orders SET status='SKIPPED',prepared=NULL,reason='Stopped before broadcast' WHERE id=$1",[id]);await connection.query('COMMIT');return 'SKIPPED';
 }
 await connection.query("UPDATE live_orders SET status='BROADCAST' WHERE id=$1",[id]);
 // Initiate the request while holding the control lock, release immediately after the durable transition.
 // A subsequent stop can interrupt future orders, not this already-started broadcast.
 const sending=adapter.send(prepared,s.confirmationTimeoutMs??30000).then(result=>({result,error:false}),()=>({result:null,error:true}));
 await connection.query('COMMIT');const outcome=await sending;
 if(outcome.error)await db.query("UPDATE live_orders SET status='UNKNOWN',reason='Network outcome unknown; signature persisted; no automatic replacement' WHERE id=$1",[id]);
 else await db.query("UPDATE live_orders SET status='AWAITING_RECONCILIATION',reason=$2 WHERE id=$1",[id,outcome.result?.status==='Success'?'Managed execution reported success; waiting for finalized chain evidence':'Managed response requires chain reconciliation']);
 return 'AWAITING_RECONCILIATION';
 }catch(e){await connection.query('ROLLBACK');throw e;}finally{await connection.query('SELECT pg_advisory_unlock(879025)');connection.release();}
}
export async function reconcileLive(){
 const rows=(await db.query("SELECT * FROM live_orders WHERE status IN ('PREPARED','BROADCAST','UNKNOWN','AWAITING_RECONCILIATION') ORDER BY created")).rows;if(!rows.length)return;
 const adapter=await LiveAdapter.configured();
 for(const order of rows){const status=await adapter.status(order.signature);if(!status||status.confirmationStatus!=='finalized')continue;
  const tx=await chain('getTransaction',[order.signature,{encoding:'jsonParsed',commitment:'finalized',maxSupportedTransactionVersion:0}]);if(!tx)continue;
  if(status.err){
   const wallet=order.details.wallet;const i=tx.transaction.message.accountKeys.findIndex((k:any)=>(typeof k==='string'?k:k.pubkey)===wallet);const amount=tx.meta.postBalances[i];if(!Number.isSafeInteger(amount)||!Number.isSafeInteger(tx.meta.fee))throw Error('Failed execution balance unavailable');
   const c=await db.connect();try{await c.query('BEGIN');await c.query("UPDATE balances SET lamports=$1 WHERE mode='live'",[String(amount)]);await c.query("UPDATE live_orders SET status='FAILED',prepared=NULL,details=details || $2::jsonb,reason='Finalized transaction failed; actual network fee recorded' WHERE id=$1",[order.id,JSON.stringify({fee:String(tx.meta.fee),realized:String(-BigInt(tx.meta.fee))})]);await c.query('COMMIT');}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}continue;
  }
  const wallet=order.details.wallet,mint=order.details.change.mint;const amounts=(rows:any[]):bigint=>rows.filter(b=>b.owner===wallet&&b.mint===mint).reduce((n,b)=>n+BigInt(b.uiTokenAmount.amount),0n);
  const before=amounts(tx.meta.preTokenBalances??[]),after=amounts(tx.meta.postTokenBalances??[]),side=order.details.change.side;
  const index=tx.transaction.message.accountKeys.findIndex((k:any)=>(typeof k==='string'?k:k.pubkey)===wallet);const pre=tx.meta.preBalances[index],post=tx.meta.postBalances[index];if(!Number.isSafeInteger(pre)||!Number.isSafeInteger(post)||index<0)throw Error('Cannot reconcile exact wallet balance');
  const quantity=side==='BUY'?after-before:before-after,native=side==='BUY'?BigInt(pre)-BigInt(post):BigInt(post)-BigInt(pre);if(quantity<=0n||native<=0n)throw Error('Unexpected live execution balances; manual reconciliation required');
  let tip=0n;for(const ix of [...tx.transaction.message.instructions,...(tx.meta.innerInstructions??[]).flatMap((i:any)=>i.instructions)]){const info=ix.parsed?.info;if(ix.programId==='11111111111111111111111111111111'&&ix.parsed?.type==='transfer'&&info?.source===wallet&&order.prepared?.intent?.tipAccounts?.includes(info.destination)){if(!Number.isSafeInteger(info.lamports))throw Error('Inexact tip amount');tip+=BigInt(info.lamports);}}
  const c=await db.connect();try{await c.query('BEGIN');const locked=(await c.query('SELECT status FROM live_orders WHERE id=$1 FOR UPDATE',[order.id])).rows[0];if(locked.status==='CONFIRMED'){await c.query('ROLLBACK');continue;}
   const p=(await c.query("SELECT * FROM positions WHERE mode='live' AND mint=$1 FOR UPDATE",[mint])).rows[0];const old=BigInt(p?.quantity??0),cost=BigInt(p?.cost??0);if(side==='SELL'&&quantity>old)throw Error('Live holding mismatch');
   const basis=side==='SELL'?cost*quantity/old:0n,realized=side==='SELL'?native-basis:0n;
   await c.query("INSERT INTO positions(mode,mint,quantity,cost,realized) VALUES('live',$1,$2,$3,$4) ON CONFLICT(mode,mint) DO UPDATE SET quantity=EXCLUDED.quantity,cost=EXCLUDED.cost,realized=EXCLUDED.realized",[mint,String(side==='BUY'?old+quantity:old-quantity),String(side==='BUY'?cost+native:cost-basis),String(BigInt(p?.realized??0)+realized)]);
   await c.query("UPDATE balances SET lamports=$1 WHERE mode='live'",[String(post)]);
   await c.query("UPDATE live_orders SET status='CONFIRMED',prepared=NULL,details=details || $2::jsonb,reason=NULL WHERE id=$1",[order.id,JSON.stringify({quantity:String(quantity),native:String(native),realized:String(realized),fee:String(BigInt(tx.meta.fee)+tip),tip:String(tip),executedAt:tx.blockTime==null?null:new Date(tx.blockTime*1000).toISOString(),slot:tx.slot})]);await c.query("UPDATE events SET status='CONFIRMED',reason=NULL WHERE signature=$1",[order.id.split(':')[0]]);await c.query('COMMIT');
  }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 }
}
