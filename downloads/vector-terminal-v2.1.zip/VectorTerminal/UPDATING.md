# Updating VECTOR v2 to v2.1 on Windows

This update fixes blanket rejection of Token-2022 source transactions in paper mode.
It allows verified plain/metadata-only Token-2022 mints and ignores unchanged token balances when checking program support. Transfer-fee, hook, confidential and unknown mint extensions still require additional support. Live Token-2022 execution remains disabled.

1. In your existing VectorTerminal folder, run `stop-windows.cmd`.
2. Extract the new ZIP into a temporary folder.
3. Open its VectorTerminal folder and copy its contents **into your existing VectorTerminal folder**. Choose Replace for program files.
4. Keep your existing `.env` file and the existing folder name/location. The ZIP does not contain a `.env` file. Do not delete the Docker database volume or run `docker compose down -v`.
5. In the existing folder, run `install-windows.cmd` to rebuild, then `start-windows.cmd`.
6. Sign in using the same dashboard token. The app starts paused in PAPER. Click Resume copying.

Your saved settings and history remain in the same database volume. Previously skipped trades remain skipped; the update applies to newly processed activity. A sell without a corresponding paper holding is still skipped. New trades remain subject to quote availability and your risk limits.

Verification: 37 automated tests passed with the database enabled, including the Token-2022 monitor-to-paper-fill path, exact partial sells, unchanged accounts, extension rejection and no duplicate fills. Provider responses in these tests are mocked. The particular transactions in your screenshot have not yet been reproduced from their full public signatures.
