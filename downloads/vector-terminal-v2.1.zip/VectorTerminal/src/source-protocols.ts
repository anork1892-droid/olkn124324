import {createHash} from 'node:crypto';import bs58 from 'bs58';
export const SOURCE_PROGRAMS={jupiter:'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',raydiumV4:'675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',pump:'6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P',pumpSwap:'pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA'};
export function anchorData(name:string){return bs58.encode(createHash('sha256').update('global:'+name).digest().subarray(0,8));}
export function supportedSwap(ix:{programId?:string;data?:string}){
 if(!ix.data)return false;let bytes:Uint8Array;try{bytes=bs58.decode(ix.data);}catch{return false;}
 if(ix.programId===SOURCE_PROGRAMS.raydiumV4)return bytes.length===17&&(bytes[0]===9||bytes[0]===11);
 const names=ix.programId===SOURCE_PROGRAMS.jupiter?['route','shared_accounts_route','route_with_token_ledger','shared_accounts_route_with_token_ledger','exact_out_route','shared_accounts_exact_out_route']:[SOURCE_PROGRAMS.pump,SOURCE_PROGRAMS.pumpSwap].includes(ix.programId??'')?['buy','sell']:[];
 const first=bs58.encode(bytes.subarray(0,8));return names.some(name=>anchorData(name)===first);
}
