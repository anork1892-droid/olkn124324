# VECTOR — lokal Solana copytrading-terminal

VECTOR kör en webbterminal, PostgreSQL, bakgrundsbevakning, paper trading och en avgränsad liveintegration med Jupiter Swap API V2. **Appen startar alltid i pausat PAPER-läge.** Inga verkliga affärer har gjorts under utvecklingen.

**Verifiering:** 39 automatiska tester passerar med testdatabasen aktiverad, inklusive mockade RPC/Swap-integrationer, delsäljningar, databasbeständighet, dubblettskydd, transaktionspolicy, signering med en tillfällig testnyckel och återhämtning efter ett oklart sändningsresultat. Detta är inte en verifiering av handel med riktiga pengar eller en extern säkerhetsrevision. Läs stödgränserna nedan före eventuell liveanvändning.

Version 2.2 lägger till dokumenterade Pump/PumpSwap exact-input- och versionerade köp/sälj-instruktioner, inklusive `buy_exact_sol_in` och `buy_exact_quote_in`. Källa: `pump-fun/pump-public-docs`, commit `639b87fb45c3adeffa6f7c4a1bf0cb85e392bf22`, `idl/pump.json` och `idl/pump_amm.json`. Råa saldoförändringar, SOL-motvaluta och riskkontroller krävs fortfarande.

## Uppdatering från v2/v2.1 till v2.2

Stäng appen med `stop-windows.cmd`. Packa upp v2.2 till en tillfällig mapp och kopiera innehållet i dess `VectorTerminal` till din **befintliga projektmapp**, med ersättning av programfiler. Behåll `.env` och samma mappnamn så att Compose använder samma databasvolym. Kör `install-windows.cmd` och sedan `start-windows.cmd`; välj Resume copying igen. Kör inte `docker compose down -v`. Gamla SKIPPED-rader förblir historik och spelas inte upp som nya köp. Se även `UPDATING.md`.

## Ladda ned på din Windows-dator

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) med WSL 2 och Linux-containrar. Följ dess instruktioner om virtualisering eller omstart.
- ZIP-paketet med hela denna mapp. Packa upp det, exempelvis till `C:\VectorTerminal`.
- Använd Edge, Chrome eller en annan aktuell webbläsare.

Du behöver inte installera Ollama, Python, Node.js, PostgreSQL eller Solana CLI separat för Docker-installationen. Ollama behövs inte för exakta balansberäkningar, och den här appen använder ingen AI-modell för att besluta hur mycket pengar som ska skickas.

Du behöver också en Solana mainnet RPC-adress med transaktionshistorik, exempelvis från [Helius](https://www.helius.dev/), samt en API-nyckel med Swap/Price/Tokens-åtkomst från [Jupiter](https://developers.jup.ag/portal). Leverantörernas aktuella priser och kapacitetsgränser gäller. Vi lovar inte att en gratisplan räcker för kontinuerlig drift.

## Första starten — paper trading

1. Starta Docker Desktop och vänta tills Linux-motorn är redo.
2. Kör `install-windows.cmd`. Den bygger appen och skapar slumpmässiga databas- och dashboardlösenord i `.env`. Befintliga filer bevaras.
3. Kör `start-windows.cmd`. Webbläsaren öppnas när appen är redo.
4. Logga in med värdet efter `DASHBOARD_TOKEN=` i `.env`. Öppna filen med `configure-windows.cmd` om du behöver läsa det lokalt.
5. Under **Settings → Provider configuration**, fyll i `SOLANA_RPC_URL`, valfri `SOLANA_WS_URL` och `JUPITER_API_KEY`. Sparade värden krypteras i backenddatabasen och returneras inte till webbläsaren. Tomma fält bevarar befintliga inställningar. Alternativt kan du sätta värdena i `.env` innan första start; sparade dashboardinställningar har sedan företräde.
6. Kontrollera RPC-status och välj riskgränser. Välj **Resume copying**. Paper-kontot börjar med 10 virtuella SOL. Starting balance kan ändras under Paper Trading innan den första ordern registrerats.
7. Använd **Pause copying** eller **Emergency stop** för att hindra nya order. `stop-windows.cmd` stoppar appen och databasen.

Docker Desktop och datorn måste vara igång; webbläsaren kan stängas. Tjänsterna återstartar när Docker återstartas, men appen återgår till pausat paper-läge. Första synkroniseringen sätter en startpunkt och kopierar inte historiska köp. Senare avbrott återhämtas från en sparad signatur.

## Valfritt: separat liveplånbok och explicit aktivering

Livekoden finns, men faktisk mainnet-exekvering är **inte verifierad i denna miljö**. RPC, providerbehörigheter, aktuell routekompatibilitet och plånboksinställningar måste fungera i din miljö. Paperresultat är inte bevis på lönsamhet.

1. Kör `create-trading-wallet-windows.cmd` efter installationen om du vill skapa en separat plånbok. Den använder kryptografisk nyckelgenerering i containern och sparar en Solana CLI-formatfil i `%USERPROFILE%\VectorWallet\trading-keypair.json`, utanför projektet. Endast den publika adressen skrivs ut. En befintlig nyckelfil skrivs aldrig över. Säkra en privat backup av filen.
2. Alternativt: sätt `LIVE_KEYPAIR_HOST_PATH` i `.env` till en befintlig dedikerad keypair-fil med en array av 64 byte. Använd gärna Windows-sökväg med framåtsnedstreck, exempelvis `C:/Users/dittnamn/VectorWallet/trading-keypair.json`. Skriv inte själva privatnyckeln i `.env`, Git, frontendkod eller chatten.
3. `start-live-capable-windows.cmd` startar backend med nyckelfilen monterad skrivskyddat. Det aktiverar inte livekopiering. Appen startar fortfarande pausad i PAPER.
4. Settings visar den konfigurerade publika adressen. För liveaktivering måste du skriva `ENABLE LIVE ` följt av exakt den adressen. Aktiveringen kontrollerar verkliga innehav mot tidigare bokförda livepositioner. En ny plånbok ska inte innehålla okända tokenpositioner.
5. **Resume copying** i LIVE-läget tillåter framtida liveorder inom riskgränserna. Detta kan spendera riktiga pengar. Det behövs inget finansierat konto för att testa paper-läget.

En redan startad transaktion kan inte återkallas med nödstopp. Den får landa och avstämmas. Vid `UNKNOWN` eller `AWAITING_RECONCILIATION` skickas ingen ny ersättningstransaktion; systemet väntar på finaliserad kedjeinformation. Om RPC aldrig kan avgöra utfallet förblir livekön blockerad för manuell utredning av den sparade signaturen. Radera inte orderraden för att försöka igen.

Lägesbyten raderar inte historik och flyttar inga simulerade tillgångar till live. Efter omstart måste live aktiveras igen; kvarvarande signerade transaktioner fortsätter att avstämmas via RPC när backend har tillgång till samma plånbok och provider.

## Handels- och riskfunktioner

- Målplånbok: `FZU56d9iPqohXM5XBrYYBZLi2UoUnZT4V5Qf2631tEzb`.
- Bakgrundsbevakning av finaliserade transaktioner med femsekunders polling och valfria WebSocket-notifieringar. Paginerad återhämtning har en gräns på 2 000 signaturer. En större lucka stoppar behandlingen och visas som fel.
- Tokenkonton aggregeras per ägare och mint. Procenten såld är råa sålda tokens dividerat med rått saldo före transaktionen. Återkommande delsäljningar använder det kvarvarande innehavet. SOL-proceeds eller initial insats avgör aldrig om en position är helt såld.
- BigInt används för råa token- och lamportbelopp. Decimal med hög precision används för uppskattade marknadsvärden. Visade säljprocent avrundas nedåt till två decimaler; rå kvot finns i radens tooltip och bokföringen använder hela kvoten.
- Köpstorlek: fast SOL-belopp, procent av tillgängligt saldo eller proportion av källans tillgängliga SOL när underlaget räcker. Max per affär och token gäller. Extra köp kan inaktiveras.
- Säljstrategier: exakt andel, endast full exit eller multiplikator med tak på 100 %. Ingen egen position innebär ingen säljorder.
- Riskgränser: SOL-reserv, antal positioner, likviditet, price impact, slippage, marknadsvärdesintervall, blacklist, max uppskattad transaktionskostnad och daglig realiserad förlust i UTC.
- Prioritetsavgift, Jito-tip, paper-fördröjning, paper-offertförsök och tidsgräns för det hanterade exekveringssvaret är inställbara. 1 SOL = 1 000 000 000 lamports. Nyinstallationens maxkostnad är 5 000 000 lamports, vilket ger utrymme för vanligt ATA-rent; äldre sparade värden bevaras.
- Paper använder aktuell Jupiter V2-offert vid simulerad exekvering, konservativt minimiutbelopp efter slippage och uppskattade nätverksavgifter. Otillräcklig likviditets-/prisdata ger `UNPRICEABLE` eller `SKIPPED` med orsak.
- Live använder `/order` och `/execute` med Metis-rutter. Backend kontrollerar signerare, program, associerade konton, faktiskt kodat input/minimioutput, slippage, avgifts-/tipgränser och simulerade förändringar för plånbokens tokenkonton. Godkänd signatur sparas innan nätverksanropet. Bokföringen ändras först efter finaliserad on-chain avstämning.
- Jito-tip använder den dokumenterade hanterade V2-parametern. Mottagare kontrolleras mot Jitos `getTipAccounts`. Andra tip-/relay-mottagare godkänns inte automatiskt. En separat custom-build/Jito-bundle-väg är inte implementerad.

## Dashboard och bokföring

Overview, Live Trades, Positions, Target Wallet, Analytics, Paper Trading, Settings och Logs visar verkliga sparade data. Dashboarden har portföljvärde, realiserad/uppskattad orealiserad P&L, dagens realiserade resultat, nätverkskostnader, drawdown, andel lönsamma säljavslut, positioner, source/copy-storlekar, säljandelar, latency och signaturlänkar. Win rate avser säljavslut, inte nödvändigtvis en fullständig buy-to-exit-cykel.

Positionsrader kan fällas ut till historik och observerade pris-/market-cap-grafer med tidsmarkörer för källans respektive våra affärer. Tokenikoner används när metadata och en stödd bildkälla finns; annars visas en symbolinitial. Grafer börjar där appen faktiskt har observerat data; historiska priser eller kostnadsbaser hittas inte på. Okända priser gör totalvärderingen ofullständig, och inaktuella positionsvärderingar döljs. Prisvärden och poollikviditet är marknadsuppskattningar, inte garantier för ett faktiskt exitpris.

Paper- och livebokföring ligger i separata ledgerposter och ordertabeller. Alla simulerade avslut är märkta. Marknadsvärderingar lagras separat per läge. Målets kontoöversikt anger observationstid och slot; RPC-anropen är inte en atomär snapshot över alla tokenprogram.

## Stödgränser och återstående produktarbete

Detta paket ska inte beskrivas som en oberoende granskad produktionsbot eller en komplett implementation av varje detalj i originalspecifikationen:

- Källtolkningen känner igen stödda Jupiter-, Raydium V4-, Pump- och PumpSwap-swapinstruktioner. Transfers, likviditetsoperationer, flera oförenliga tokenrörelser och okända format hoppas över. Full täckning av alla DEX:er och nya instruktioner finns inte.
- Paper stöder Token-2022 utan överföringspåverkande extensions, efter verifiering av mintens ägare, decimaler och extensions via RPC. Metadata-extensions tillåts; transferFeeConfig, hooks, konfidentiella överföringar och okända extensions stoppas med specifik orsak. Oförändrade Token-2022-saldon blockerar inte andra swaps. Token-2022 stöds fortfarande inte för liveexekvering. Live tillåter en signerare, version-0-transaktioner och verifierade klassiska `route`/`shared_accounts_route`-format. Nyare routevarianter stoppas tills deras layout verifierats. Detta kan begränsa vilka aktuella Jupiter-offerter som kan utföras.
- Frontend är React 19/TypeScript med esbuild och en Express-backend. Next.js används inte; appen byggs och körs som en lokal Docker-tjänst.
- Historisk läsning sker på begäran i batcher om 20 transaktioner, helt separat från orderkön. Resultat rekonstrueras endast för observerade, sammanhängande noll-till-noll-cykler. Det är inte en komplett livstidsanalys; analyserna är begränsade till 5 000 importerade transaktioner. Automatiskt optimerade prioritetsavgifter och andra custom execution strategies än den dokumenterade hanterade vägen ingår inte.
- Windows-kommandofilerna är granskade, men Windows-körning är inte verifierad här. Testerna och Docker/browserkontrollerna kördes i Linux.
- Verklig mainnet-kopiering, verkligt betalda transaktioner, providerplanernas prestanda och Jito-landing är inte verifierade. I byggmiljön blockeras `api.jup.ag` med proxy CONNECT 403. Ingen verklig privatnyckel användes.

## Beroendekontroll

`npm audit --omit=dev` rapporterar inga höga eller kritiska sårbarheter, men tre måttliga poster kvarstår i kedjan `@solana/web3.js → jayson → stream-json`. Det är samma underliggande parserberoende och dess överordnade paket. Den korrigerade stream-json-versionen har ett inkompatibelt modul-API och har därför inte tvingats in. UUID-beroendet har uppdaterats till den korrigerade, CommonJS-kompatibla versionen 11.1.1 och hela testsviten har körts igen. Återstående parservarningar behöver hanteras vid en kompatibel SDK-uppgradering.

## Drift och backup

Docker-volymen `vector-db` innehåller databasen, med Compose-projektets prefix. `stop`/`up` bevarar data; `docker compose down -v` raderar volymen. Behåll projektmapp/Compose-projektnamn vid uppdatering, kör installationen igen för att bygga ny kod och säkerhetskopiera databasen före uppgradering.

Behåll `.env` tillsammans med en säker databasbackup: `DASHBOARD_TOKEN` används också för att härleda krypteringsnyckeln till sparade providerinställningar. Ett tokenbyte utan migrering gör dessa inställningar oläsbara. Plånboksnyckeln behöver sin egen privata backup. Paketet innehåller inga nycklar, `.env` eller databasfiler.

Tjänsten binder till loopback och är avsedd för en lokal användare. Exponera den inte som en publik fleranvändartjänst. Inloggningssessioner återställs vid omstart. Använd UTC för tolkning av dagliga riskgränser.

## Utveckling och tester

Utanför Docker krävs Node 24 och PostgreSQL. Sätt `DATABASE_URL` till din utvecklingsdatabas och `DASHBOARD_TOKEN` till en slumpmässig sträng med minst 24 tecken.

```bash
npm ci
npm run build
npm run check
npm test
TEST_DATABASE_URL=postgresql://USER:PASSWORD@HOST:PORT/DATABASE npm test
npm run dev
```

Databastester använder isolerade tillfälliga scheman och rensar efter sig. Utan `TEST_DATABASE_URL` markeras de som skipped. Testkörningen med databas gav **39 godkända, 0 fel, 0 skipped**. Liveadaptertester använder genererade testnycklar, syntetiska transaktioner och mockad transport; de sänder inte till Solana. Testerna inkluderar felaktig mottagare, otillåtet program, ändrat tokenägarskap, för låg output och manipulerat kodat slippagevillkor.

Den slutliga Docker-imagen byggdes och startade med godkända healthchecks. Chromium-testet passerade inloggning, alla åtta vyer, inställningssparande, nödstopp och nekad liveaktivering, med desktop- och mobilskärmbilder. Instansen saknade provideruppgifter; dessa kontroller verifierar därför gränssnitt och lokal drift, inte verkliga marknadsflöden.

## Verifierade dokumentationskällor

- [Jupiter docs](https://github.com/jup-ag/docs), commit `0066fdeab9aebddae99d68f58ed121d58153e88a`: V2 order/execute, Price V3, Tokens V2.
- [Jupiter CPI IDL](https://github.com/jup-ag/jupiter-cpi), commit `12bc5f67b94a2c3edc74d6e721a19442124a0bad`: klassiska route-layouts. `src/jupiter-route-types.json` är ett extrakt av denna schemafil; okända enumvarianter godkänns inte.
- [Raydium SDK V2](https://github.com/raydium-io/raydium-sdk-V2): `src/common/programId.ts` och `src/raydium/liquidity/instruction.ts`.
- [Pump public docs](https://github.com/pump-fun/pump-public-docs): Pump/PumpSwap-programadresser och buy/sell-instruktioner.

### Reproducerbart webbläsartest

Starta en separat pausad paper-instans utan liveplånbok. Installera utvecklingsberoenden med `npm ci`, därefter `npx playwright install chromium`. Kör `npm run test:browser` med rätt `DASHBOARD_TOKEN` i lokal `.env`. `TEST_BASE_URL` kan ändra testad adress och `CHROMIUM_PATH` kan peka på en redan installerad Chromium. Testet vägrar kontrollåtgärder om backend har en liveplånbok konfigurerad. Det kontrollerar alla åtta vyer, inställningssparande, nödstopp och nekad liveaktivering; skärmbilder skrivs till den ignorerade mappen `test-results`.
