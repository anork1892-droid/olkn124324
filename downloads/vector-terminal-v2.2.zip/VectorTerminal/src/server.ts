import {backfillHistory,historyState} from './history.ts';
import {loadProviders,saveProviders,providerStatus} from './providers.ts';
import {refreshPortfolio,portfolioState} from './portfolio.ts';
import {activateLive,liveConfiguration} from './live-engine.ts';
import {subscribe} from './subscription.ts';
import express from 'express';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {z} from 'zod';
import {db,initialize,state,log} from './store.ts';
import {poll,health} from './monitor.ts';
import {TARGET} from './core.ts';
const token=process.env.DASHBOARD_TOKEN;if(!token||token.length<24)throw Error('Set DASHBOARD_TOKEN to at least 24 random characters');
let stopSubscription:()=>void=()=>{};
const app=express(),sessions=new Map<string,number>();app.disable('x-powered-by');app.use(express.json({limit:'16kb'}));
app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Cache-Control':'no-store','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'"});if(!['localhost','127.0.0.1'].includes(req.hostname))return res.sendStatus(403);if(req.method!=='GET'&&req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`)return res.sendStatus(403);next();});
let attempts=0,windowStart=Date.now();
app.post('/api/login',(req,res)=>{if(Date.now()-windowStart>60000){attempts=0;windowStart=Date.now();}if(++attempts>10)return res.sendStatus(429);const input=Buffer.from(String(req.body.token??'')),expected=Buffer.from(token);if(input.length!==expected.length||!timingSafeEqual(input,expected))return res.sendStatus(401);const id=randomBytes(32).toString('hex');sessions.set(id,Date.now()+8*3600000);res.setHeader('Set-Cookie',`session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);res.json({ok:true});});
app.use('/api',(req,res,next)=>{const id=req.headers.cookie?.match(/(?:^|; )session=([a-f0-9]+)/)?.[1];if(!id||(sessions.get(id)??0)<Date.now())return res.sendStatus(401);next();});
app.get('/api/state',async(_req,res)=>res.json({...await state(),health,providers:providerStatus(),portfolio:await portfolioState(),target:TARGET,liveConfiguration:await liveConfiguration(),capabilities:{live:true,quotes:true,monitoring:'finalized polling',nativeSolSwaps:true}}));
app.get('/api/token/:mint/icon',async(req,res)=>{
 if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(req.params.mint))return res.sendStatus(404);
 const row=(await db.query("SELECT p->>'icon' AS icon FROM snapshots s CROSS JOIN LATERAL jsonb_array_elements(s.data->'positions') p WHERE p->>'mint'=$1 AND p->>'icon' IS NOT NULL ORDER BY s.id DESC LIMIT 1",[req.params.mint])).rows[0];if(!row?.icon)return res.sendStatus(404);
 try{const url=new URL(row.icon);if(url.protocol!=='https:'||!['static.jup.ag','arweave.net','ipfs.io'].includes(url.hostname)||url.username||url.password)return res.sendStatus(404);const r=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(5000)});const type=r.headers.get('content-type')?.split(';')[0];if(!r.ok||!['image/png','image/jpeg','image/webp'].includes(type??'')||!r.body)return res.sendStatus(404);const chunks:Uint8Array[]=[];let size=0;const reader=r.body.getReader();while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>2000000){await reader.cancel();return res.sendStatus(413);}chunks.push(value);}res.type(type!).send(Buffer.concat(chunks));}catch{res.sendStatus(404);}
});
app.get('/api/token/:mint',async(req,res)=>{
 if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(req.params.mint))return res.status(400).json({error:'Invalid mint'});
 const mode=(await db.query('SELECT value FROM config WHERE id=1')).rows[0].value.mode;
 const history=(await db.query("SELECT created,p AS position FROM snapshots s CROSS JOIN LATERAL jsonb_array_elements(s.data->'positions') p WHERE s.kind=$1 AND p->>'mint'=$2 ORDER BY s.id DESC LIMIT 300",[mode,req.params.mint])).rows;
 res.json({history:history.reverse(),estimated:true});
});
app.get('/api/events',async(req,res)=>{res.set({'Content-Type':'text/event-stream','Connection':'keep-alive'});res.flushHeaders();const timer=setInterval(()=>res.write(`data: ${JSON.stringify(health)}\n\n`),3000);req.on('close',()=>clearInterval(timer));});
const schema=z.object({quoteRetries:z.number().int().min(0).max(3),confirmationTimeoutMs:z.number().int().min(5000).max(60000),jitoTipLamports:z.string().regex(/^\d{1,9}$/),buySizing:z.enum(['fixed','balance','proportional']),balanceBps:z.number().int().min(1).max(10000),maxTradeLamports:z.string().regex(/^[1-9]\d{0,12}$/),minMarketCapUsd:z.number().nonnegative().nullable(),maxMarketCapUsd:z.number().positive().nullable(),priorityFeeLamports:z.string().regex(/^\d{1,9}$/),maxCostLamports:z.string().regex(/^[1-9]\d{0,9}$/),dailyLossLamports:z.string().regex(/^[1-9]\d{0,12}$/),executionDelayMs:z.number().int().min(0).max(5000),blacklist:z.array(z.string().regex(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/)).max(100),fixedLamports:z.string().regex(/^[1-9]\d{0,11}$/),maxPerTokenLamports:z.string().regex(/^[1-9]\d{0,12}$/),reserveLamports:z.string().regex(/^\d{1,12}$/),sellStrategy:z.enum(['exact','full','multiplier']),multiplierBps:z.number().int().min(1).max(100000),additionalBuys:z.boolean(),slippageBps:z.number().int().min(0).max(1000),maxImpactBps:z.number().int().min(0).max(1000),minLiquiditySol:z.number().min(0).max(1e9),maxPositions:z.number().int().min(1).max(100)}).strict();
app.put('/api/settings',async(req,res)=>{const parsed=schema.safeParse(req.body);if(!parsed.success)return res.status(400).json({error:parsed.error.message});await db.query('UPDATE config SET value=value || $1::jsonb WHERE id=1',[JSON.stringify(parsed.data)]);await log('Paper strategy settings updated.');res.json({ok:true});});
app.post('/api/paper/balance',async(req,res)=>{
 const amount=String(req.body.lamports??'');if(!/^[1-9]\d{0,14}$/.test(amount))return res.status(400).json({error:'Invalid starting balance'});
 const c=await db.connect();try{await c.query('BEGIN');await c.query("SELECT lamports FROM balances WHERE mode='paper' FOR UPDATE");if((await c.query('SELECT 1 FROM paper_orders LIMIT 1')).rowCount){await c.query('ROLLBACK');return res.status(409).json({error:'Starting balance can only change before the first recorded paper order; history is never erased'});}await c.query("UPDATE balances SET lamports=$1 WHERE mode='paper'",[amount]);await c.query("DELETE FROM snapshots WHERE kind='paper'");await c.query('COMMIT');res.json({ok:true});}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
});
app.put('/api/providers',async(req,res)=>{try{await saveProviders(req.body);stopSubscription();stopSubscription=subscribe(poll);void refreshPortfolio();await log('Provider settings updated (values redacted)');res.json({ok:true});}catch{res.status(400).json({error:'Invalid provider settings or encrypted settings could not be saved'});}});
app.post('/api/mode',async(req,res)=>{
 try{if(req.body.mode==='live'){await activateLive(String(req.body.wallet??''),String(req.body.confirmation??''));}
 else if(req.body.mode==='paper'){await db.query("UPDATE config SET value=value || '{\"mode\":\"paper\",\"paused\":true}'::jsonb WHERE id=1");await log('Switched to paper mode; histories preserved');}
 else return res.status(400).json({error:'Invalid mode'});res.json({ok:true});}catch(e){res.status(400).json({error:e instanceof Error?e.message:'Activation failed'});}
});
app.get('/api/target/history',async(_req,res)=>res.json(await historyState()));
app.post('/api/target/history',async(_req,res)=>{try{res.json(await backfillHistory());}catch(e){res.status(400).json({error:e instanceof Error?e.message.replace(/https?:\/\/\S+/g,'[provider]'):'Historical retrieval failed'});}});
app.post('/api/control',async(req,res)=>{const action=req.body.action;if(!['pause','resume','stop'].includes(action))return res.status(400).json({error:'Unsupported control action'});await db.query('UPDATE config SET value=value || $1::jsonb WHERE id=1',[JSON.stringify({paused:action!=='resume',emergency:action==='stop'})]);await log(`Control: ${action}`);res.json({ok:true});});
app.use(express.static(new URL('../web',import.meta.url).pathname));
app.use((err:Error,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{console.error(err.message);res.status(500).json({error:'Server operation failed; consult backend logs'});});
await initialize();await loadProviders();await db.query("UPDATE config SET value=value || '{\"mode\":\"paper\",\"paused\":true}'::jsonb WHERE id=1");const server=app.listen(Number(process.env.PORT??8790),process.env.HOST??'127.0.0.1',()=>console.log('Terminal listening on loopback port '+(process.env.PORT??8790)));
void refreshPortfolio();const portfolioTimer=setInterval(()=>void refreshPortfolio(),60000);
await poll();const timer=setInterval(()=>void poll(),5000);stopSubscription=subscribe(poll);
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{clearInterval(timer);clearInterval(portfolioTimer);stopSubscription();server.close(()=>void db.end());});
