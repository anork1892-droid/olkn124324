import bs58 from 'bs58';
import {anchorData,SOURCE_PROGRAMS} from '../src/source-protocols.ts';
import {test} from 'node:test';import assert from 'node:assert/strict';
import {sellAmount,percentage,paperFill,classify,TARGET,WSOL,JUPITER,TOKEN_2022,type Transaction} from '../src/core.ts';
test('repeated partial exits use remaining quantities',()=>{let ours=250000n;const a=sellAmount(ours,250000n,1000000n);assert.equal(a,62500n);ours-=a;const b=sellAmount(ours,375000n,750000n);assert.equal(b,93750n);ours-=b;assert.equal(sellAmount(ours,375000n,375000n),93750n);});
test('appreciation and proceeds do not determine sell fraction',()=>{assert.equal(percentage(772700n,1000000n),'77.27');assert.equal(sellAmount(250000n,772700n,1000000n),193175n);});
test('additional buys change denominator, no holdings cannot sell',()=>{assert.equal(sellAmount(500n,400n,2000n),100n);assert.equal(sellAmount(0n,400n,2000n),0n);});
test('full exits and capped multiplier',()=>{assert.equal(sellAmount(100n,20n,100n,'full'),0n);assert.equal(sellAmount(100n,80n,100n,'multiplier',20000),100n);});
test('invalid quantities fail closed, large integers retain precision',()=>{assert.throws(()=>sellAmount(1n,11n,10n));assert.equal(sellAmount(10n**24n,1n,4n),25n*10n**22n);});
function tx(program=JUPITER):Transaction {return {meta:{err:null,fee:5000,preTokenBalances:[{accountIndex:1,mint:'token',owner:TARGET,uiTokenAmount:{amount:'600000',decimals:6}},{accountIndex:2,mint:'token',owner:TARGET,uiTokenAmount:{amount:'400000',decimals:6}},{accountIndex:3,mint:WSOL,owner:TARGET,uiTokenAmount:{amount:'0',decimals:9}}],postTokenBalances:[{accountIndex:1,mint:'token',owner:TARGET,uiTokenAmount:{amount:'200000',decimals:6}},{accountIndex:2,mint:'token',owner:TARGET,uiTokenAmount:{amount:'400000',decimals:6}},{accountIndex:3,mint:WSOL,owner:TARGET,uiTokenAmount:{amount:'1000000000',decimals:9}}]},transaction:{message:{instructions:[{programId:program,data:anchorData('route')}]}}};}
test('aggregates all source accounts and computes 40% sale',()=>{const c=classify(tx()).changes[0];assert.equal(c.before,1000000n);assert.equal(c.after,600000n);assert.equal(percentage(c.quantity,c.before),'40.00');});
test('transfers and failed transactions do not copy',()=>{assert.equal(classify(tx('transfer')).changes.length,0);const t=tx();t.meta.err={failed:true};assert.equal(classify(t).changes.length,0);});
test('ambiguous native SOL swaps are rejected',()=>{const t=tx();t.meta.postTokenBalances=t.meta.postTokenBalances.filter(x=>x.mint!==WSOL);assert.equal(classify(t).changes.length,0);});
test('paper buys, additional buys, cost basis and partial sales',()=>{let r=paperFill({quantity:0n,cost:0n,realized:0n},100000n,'BUY',{input:1000n,output:100n,fee:10n,impactBps:10,liquiditySol:20,observedAt:Date.now()});r=paperFill(r.position,r.cash,'BUY',{input:1000n,output:100n,fee:10n,impactBps:10,liquiditySol:20,observedAt:Date.now()});assert.equal(r.position.quantity,200n);r=paperFill(r.position,r.cash,'SELL',{input:50n,output:700n,fee:10n,impactBps:10,liquiditySol:20,observedAt:Date.now()});assert.equal(r.position.quantity,150n);assert.equal(r.realized,185n);assert.equal(r.position.cost,1515n);assert.equal(r.cash,98670n);});
test('unavailable or stale quotes cannot fabricate paper fills',()=>{const p={quantity:0n,cost:0n,realized:0n};assert.throws(()=>paperFill(p,100n,'BUY',{input:10n,output:0n,fee:0n,impactBps:0,liquiditySol:0,observedAt:Date.now()}));assert.throws(()=>paperFill(p,100n,'BUY',{input:10n,output:10n,fee:0n,impactBps:0,liquiditySol:0,observedAt:0}));});
test('native SOL buy accounts for ATA rent and fee',()=>{
 const t:Transaction={meta:{err:null,fee:5000,preBalances:[2000000000,0],postBalances:[998955000,1040000],preTokenBalances:[],postTokenBalances:[{accountIndex:1,mint:'token',owner:TARGET,uiTokenAmount:{amount:'1000000',decimals:6}}]},transaction:{message:{accountKeys:[TARGET,'ATA'],instructions:[{programId:JUPITER,data:anchorData('route')}]}}};
 const c=classify(t);assert.equal(c.changes.length,1);assert.equal(c.changes[0].side,'BUY');assert.equal(c.changes[0].quantity,1000000n);
});

test('unchanged Token-2022 accounts do not block standard swaps',()=>{
 const t=tx();const unrelated={accountIndex:4,mint:'unchanged',owner:TARGET,programId:TOKEN_2022,uiTokenAmount:{amount:'123',decimals:6}};
 t.meta.preTokenBalances.push(unrelated);t.meta.postTokenBalances.push({...unrelated});
 assert.equal(classify(t).changes[0].quantity,400000n);
});
test('Token-2022 raw balances preserve aggregate partial-sell fractions',()=>{
 const t=tx();for(const b of [...t.meta.preTokenBalances,...t.meta.postTokenBalances])if(b.mint==='token')b.programId=TOKEN_2022;
 const c=classify(t).changes[0];assert.equal(c.tokenProgram,TOKEN_2022);assert.equal(c.before,1000000n);assert.equal(c.quantity,400000n);assert.equal(sellAmount(250000n,c.quantity,c.before),100000n);
 t.transaction.message.instructions.push({programId:TOKEN_2022,parsed:{type:'transferChecked'}});
 assert.match(classify(t).reason!,/separate top-level transfer/);
});
test('changed unknown token programs remain unsupported',()=>{
 const t=tx();for(const b of [...t.meta.preTokenBalances,...t.meta.postTokenBalances])if(b.mint==='token')b.programId='unknown';
 assert.match(classify(t).reason!,/Unsupported token program: unknown/);
});

test('Pump exact-SOL purchases inside router CPI use actual native and token balances',()=>{
 const data=bs58.encode(Buffer.concat([Buffer.from([56,252,116,8,158,223,205,95]),Buffer.alloc(18)]));
 const t:Transaction={meta:{err:null,fee:5000,preBalances:[2000000000,0],postBalances:[998955000,1040000],preTokenBalances:[],postTokenBalances:[{accountIndex:1,mint:'token',owner:TARGET,programId:TOKEN_2022,uiTokenAmount:{amount:'1000000',decimals:6}}],innerInstructions:[{instructions:[{programId:SOURCE_PROGRAMS.pump,data}]}]},transaction:{message:{accountKeys:[TARGET,'ATA'],instructions:[{programId:'router',data:anchorData('route')}]}}};
 const c=classify(t).changes[0];assert.equal(c.side,'BUY');assert.equal(c.sourceSpent,1000000000n);assert.equal(c.quantity,1000000n);assert.equal(c.tokenProgram,TOKEN_2022);
});
