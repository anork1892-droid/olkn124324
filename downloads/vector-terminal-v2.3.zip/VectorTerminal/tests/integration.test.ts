import {test} from 'node:test';import assert from 'node:assert/strict';import pg from 'pg';import {executePaper,type Quotes} from '../src/execution.ts';
const url=process.env.TEST_DATABASE_URL;
test('PostgreSQL atomic fills, duplicate recovery, missing quotes and restart persistence',{skip:!url},async()=>{
 const admin=new pg.Pool({connectionString:url});const schema='test_'+Date.now();await admin.query(`CREATE SCHEMA ${schema}`);
 const pool=new pg.Pool({connectionString:url,options:`-c search_path=${schema}`});
 try{await pool.query(`CREATE TABLE config(id int PRIMARY KEY,value jsonb);CREATE TABLE balances(mode text PRIMARY KEY,lamports numeric(78,0));CREATE TABLE positions(mode text,mint text,quantity numeric(78,0),cost numeric(78,0),realized numeric(78,0),PRIMARY KEY(mode,mint));INSERT INTO balances VALUES('paper',10000000000);`);
 await pool.query('INSERT INTO config VALUES(1,$1)',[JSON.stringify({mode:'paper',paused:false,emergency:false,fixedLamports:'100000000',maxPerTokenLamports:'1000000000',reserveLamports:'500000000',sellStrategy:'exact',multiplierBps:10000,additionalBuys:true,slippageBps:100,maxImpactBps:200,minLiquiditySol:10,maxPositions:10})]);
 const quotes:Quotes={async quote(_mint,side,input){return {input,output:side==='BUY'?1000000n:input*100n,fee:5000n,impactBps:10,liquiditySol:100,observedAt:Date.now()};}};
 const buy={mint:'TEST',before:0n,after:1000000n,quantity:1000000n,decimals:6,side:'BUY' as const};
 assert.equal(await executePaper(pool,quotes,'buy',buy),'SIMULATED');assert.equal(await executePaper(pool,quotes,'buy',buy),'DUPLICATE');
 const sale={...buy,before:1000000n,after:750000n,quantity:250000n,side:'SELL' as const};assert.equal(await executePaper(pool,quotes,'sell25',sale),'SIMULATED');
 assert.equal((await pool.query('SELECT quantity FROM positions')).rows[0].quantity,'750000');
 assert.equal(await executePaper(pool,quotes,'sell50',{...sale,before:750000n,after:375000n,quantity:375000n}),'SIMULATED');
 const reconnected=new pg.Pool({connectionString:url,options:`-c search_path=${schema}`});assert.equal((await reconnected.query('SELECT quantity FROM positions')).rows[0].quantity,'375000');await reconnected.end();
 assert.equal(await executePaper(pool,{async quote(){throw Error('offline');}},'offline',buy),'UNPRICEABLE');
 assert.equal(await executePaper(pool,quotes,'unknown',{...sale,mint:'OTHER'}),'SKIPPED');
 assert.equal(await executePaper(pool,quotes,'exit',{...sale,before:375000n,after:0n,quantity:375000n}),'SIMULATED');assert.equal((await pool.query('SELECT quantity FROM positions')).rows[0].quantity,'0');
 await pool.query(`UPDATE config SET value=value || '{"emergency":true}'::jsonb`);assert.equal(await executePaper(pool,quotes,'stopped',buy),'SKIPPED');
 }finally{await pool.end();await admin.query(`DROP SCHEMA ${schema} CASCADE`);await admin.end();}
});
test('emergency control remains responsive while an order waits on its quote',{skip:!url},async()=>{
 const admin=new pg.Pool({connectionString:url});const schema='stop_'+Date.now();await admin.query(`CREATE SCHEMA ${schema}`);const pool=new pg.Pool({connectionString:url,options:`-c search_path=${schema}`});
 try{
 await pool.query(`CREATE TABLE config(id int PRIMARY KEY,value jsonb);CREATE TABLE balances(mode text PRIMARY KEY,lamports numeric(78,0));CREATE TABLE positions(mode text,mint text,quantity numeric(78,0),cost numeric(78,0),realized numeric(78,0),PRIMARY KEY(mode,mint));INSERT INTO balances VALUES('paper',10000000000);`);
 await pool.query('INSERT INTO config VALUES(1,$1)',[JSON.stringify({mode:'paper',paused:false,fixedLamports:'100000000',maxPerTokenLamports:'1000000000',reserveLamports:'500000000',maxPositions:10,additionalBuys:true,slippageBps:100,maxImpactBps:200,minLiquiditySol:10})]);
 let release!:()=>void,started!:()=>void;const waiting=new Promise<void>(r=>started=r),gate=new Promise<void>(r=>release=r);
 const order=executePaper(pool,{async quote(_m,_s,input){started();await gate;return {input,output:1000n,fee:5000n,impactBps:10,liquiditySol:100,observedAt:Date.now()};}},'pending',{mint:'TOKEN',side:'BUY',before:0n,after:1000n,quantity:1000n,decimals:6});
 await waiting;await pool.query(`UPDATE config SET value=value || '{"emergency":true}'::jsonb`);release();assert.equal(await order,'SKIPPED');assert.equal((await pool.query('SELECT count(*) FROM positions')).rows[0].count,'0');
 }finally{await pool.end();await admin.query(`DROP SCHEMA ${schema} CASCADE`);await admin.end();}
});

test('paper exit impact is independent, controls persist, manual close uses current holdings exactly once',{skip:!url},async()=>{
 const admin=new pg.Pool({connectionString:url}),schema='exits_'+Date.now();await admin.query(`CREATE SCHEMA ${schema}`);const pool=new pg.Pool({connectionString:url,options:`-c search_path=${schema}`});
 try{
 await pool.query(`CREATE TABLE config(id int PRIMARY KEY,value jsonb);CREATE TABLE balances(mode text PRIMARY KEY,lamports numeric(78,0));CREATE TABLE positions(mode text,mint text,quantity numeric(78,0),cost numeric(78,0),realized numeric(78,0),PRIMARY KEY(mode,mint));INSERT INTO balances VALUES('paper',10000000000);`);
 await pool.query('INSERT INTO config VALUES(1,$1)',[JSON.stringify({mode:'paper',paused:false,emergency:false,fixedLamports:'100000000',maxPerTokenLamports:'1000000000',reserveLamports:'500000000',sellStrategy:'exact',multiplierBps:10000,additionalBuys:true,slippageBps:100,maxImpactBps:200,paperSellImpactBps:null,minLiquiditySol:10,maxPositions:10})]);
 const change={mint:'TEST',before:0n,after:1000000n,quantity:1000000n,decimals:6,side:'BUY' as const};let impact=1200,offline=false;
 const quotes:Quotes={async quote(_m,side,input){if(offline)throw Error('unavailable');return {input,output:side==='BUY'?1000000n:input*100n,fee:5000n,impactBps:impact,liquiditySol:100,observedAt:Date.now()};}};
 assert.equal(await executePaper(pool,quotes,'expensive-buy',change),'SKIPPED');assert.match((await pool.query("SELECT reason FROM paper_orders WHERE id='expensive-buy'")).rows[0].reason,/BUY price impact 12.00% exceeds 2.00%/);
 impact=100;assert.equal(await executePaper(pool,quotes,'buy',change),'SIMULATED');impact=1200;
 const sale={...change,side:'SELL' as const,before:1000000n,after:500000n,quantity:500000n};
 assert.equal(await executePaper(pool,quotes,'partial-exit',sale),'SIMULATED');assert.equal((await pool.query('SELECT quantity FROM positions')).rows[0].quantity,'500000');
 await pool.query(`UPDATE config SET value=value || '{"paperSellImpactBps":500}'::jsonb`);
 assert.equal(await executePaper(pool,quotes,'capped-exit',sale),'SKIPPED');assert.match((await pool.query("SELECT reason FROM paper_orders WHERE id='capped-exit'")).rows[0].reason,/SELL price impact 12.00% exceeds 5.00%/);
 await pool.query(`UPDATE config SET value=value || '{"paperSellImpactBps":null,"dailyLossLamports":"1","sellStrategy":"multiplier","multiplierBps":100}'::jsonb`);
 offline=true;assert.equal(await executePaper(pool,quotes,'no-quote',sale,{closePosition:true}),'UNPRICEABLE');offline=false;
 await pool.query(`UPDATE config SET value=value || '{"paused":true}'::jsonb`);assert.equal(await executePaper(pool,quotes,'paused-close',sale,{closePosition:true}),'SKIPPED');
 await pool.query(`UPDATE config SET value=value || '{"paused":false}'::jsonb`);
 assert.equal(await executePaper(pool,quotes,'manual',sale,{closePosition:true}),'SIMULATED');assert.equal((await pool.query('SELECT quantity FROM positions')).rows[0].quantity,'0');
 assert.equal(await executePaper(pool,quotes,'manual',sale,{closePosition:true}),'DUPLICATE');assert.equal(await executePaper(pool,quotes,'manual-again',sale,{closePosition:true}),'SKIPPED');
 }finally{await pool.end();await admin.query(`DROP SCHEMA ${schema} CASCADE`);await admin.end();}
});
