import {test} from 'node:test';import assert from 'node:assert/strict';
import {checkPaperMint,validatePaperMint} from '../src/token-policy.ts';import {TOKEN,TOKEN_2022} from '../src/core.ts';
function mint(extensions:unknown[]=[]){return {owner:TOKEN_2022,data:{parsed:{type:'mint',info:{isInitialized:true,decimals:6,extensions}}}};}
test('paper allows plain and metadata-only Token-2022 mints',()=>{
 checkPaperMint(mint(),6);checkPaperMint(mint([{extension:'metadataPointer'},{extension:'tokenMetadata'}]),6);
});
test('paper rejects transfer fees, hooks, confidential and unknown extensions',()=>{
 for(const extension of ['transferFeeConfig','transferHook','confidentialTransferMint','nonTransferable','defaultAccountState','futureExtension'])assert.throws(()=>checkPaperMint(mint([{extension}]),6),new RegExp(extension));
});
test('paper mint verification rejects wrong owner, decimals and unparsed responses',()=>{
 assert.throws(()=>checkPaperMint({...mint(),owner:TOKEN},6));assert.throws(()=>checkPaperMint(mint(),9));assert.throws(()=>checkPaperMint({owner:TOKEN_2022,data:['raw','base64']},6));assert.throws(()=>checkPaperMint(mint([{}]),6));
});
test('Token-2022 RPC failures never expose credential-bearing endpoints',async()=>{
 const oldFetch=globalThis.fetch,oldRpc=process.env.SOLANA_RPC_URL;
 process.env.SOLANA_RPC_URL='https://rpc.test/?api-key=SECRET';globalThis.fetch=async()=>{throw Error('https://rpc.test/?api-key=SECRET');};
 try{await assert.rejects(validatePaperMint({mint:'MINT',tokenProgram:TOKEN_2022,decimals:6,side:'BUY',before:0n,after:1n,quantity:1n}),e=>e instanceof Error&&e.message.includes('RPC unavailable')&&!e.message.includes('SECRET'));}finally{globalThis.fetch=oldFetch;if(oldRpc===undefined)delete process.env.SOLANA_RPC_URL;else process.env.SOLANA_RPC_URL=oldRpc;}
});
