import {test} from 'node:test';import assert from 'node:assert/strict';import bs58 from 'bs58';import {anchorData,supportedSwap,SOURCE_PROGRAMS} from '../src/source-protocols.ts';
test('recognized source programs require swap discriminators; pool deposits are not purchases',()=>{assert(supportedSwap({programId:SOURCE_PROGRAMS.pumpSwap,data:anchorData('buy')}));assert(supportedSwap({programId:SOURCE_PROGRAMS.pump,data:anchorData('sell')}));assert(!supportedSwap({programId:SOURCE_PROGRAMS.pumpSwap,data:anchorData('deposit')}));const data=Buffer.alloc(17);data[0]=9;assert(supportedSwap({programId:SOURCE_PROGRAMS.raydiumV4,data:bs58.encode(data)}));assert(!supportedSwap({programId:SOURCE_PROGRAMS.jupiter}));});

test('official Pump and PumpSwap exact-input and versioned swap discriminators',()=>{
 // Discriminators from pump-fun/pump-public-docs IDLs, independently of anchorData.
 const pump=[ [56,252,116,8,158,223,205,95], [194,171,28,70,104,77,91,47], [225,247,80,30,213,179,132,136], [184,23,238,97,103,197,211,61], [7,5,29,196,245,23,101,80], [93,246,130,60,231,233,64,178], [28,146,222,119,38,196,105,213] ];
 const amm=[ [198,46,21,82,180,217,232,112], [194,171,28,70,104,77,91,47], [184,23,238,97,103,197,211,61], [93,246,130,60,231,233,64,178] ];
 for(const [programId,discriminators] of [[SOURCE_PROGRAMS.pump,pump],[SOURCE_PROGRAMS.pumpSwap,amm]] as const)for(const discriminator of discriminators){
  const data=bs58.encode(Buffer.concat([Buffer.from(discriminator),Buffer.alloc(16)]));
  assert(supportedSwap({programId,data}));assert(!supportedSwap({programId:'untrusted',data}));assert(!supportedSwap({programId,data:bs58.encode(Buffer.from(discriminator))}));
 }
 assert(!supportedSwap({programId:SOURCE_PROGRAMS.pump,data:anchorData('create_v2')}));
});
