import {TOKEN_2022,type Change} from './core.ts';

// Metadata extensions do not alter raw transfers. Fees, hooks, confidential balances,
// freeze defaults and unknown extensions need their own accounting policy.
const metadataExtensions=new Set(['metadataPointer','tokenMetadata','groupPointer','tokenGroup','groupMemberPointer','tokenGroupMember','mintCloseAuthority']);
export function checkPaperMint(account:any,decimals:number):void{
 const data=account?.data?.parsed;
 if(account?.owner!==TOKEN_2022||data?.type!=='mint'||data.info?.isInitialized!==true||data.info.decimals!==decimals)throw Error('Token-2022 mint identity or decimals could not be verified');
 const extensions=data.info.extensions??[];
 if(!Array.isArray(extensions))throw Error('Token-2022 mint extension data unavailable');
 for(const entry of extensions){
  if(!entry||typeof entry.extension!=='string')throw Error('Token-2022 mint extension data unavailable');
  if(!metadataExtensions.has(entry.extension))throw Error('Token-2022 extension not supported for paper fills: '+entry.extension);
 }
}
export async function validatePaperMint(change:Change):Promise<void>{
 if(change.tokenProgram!==TOKEN_2022)return;
 const endpoint=process.env.SOLANA_RPC_URL;
 if(!endpoint)throw Error('Solana RPC required to verify Token-2022 mint extensions');
 let account:any;
 try{
  const response=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'getAccountInfo',params:[change.mint,{encoding:'jsonParsed',commitment:'finalized'}]}),signal:AbortSignal.timeout(10000)});
  if(!response.ok)throw Error();
  const body=await response.json();if(body.error)throw Error();account=body.result?.value;
 }catch{throw Error('Token-2022 mint verification RPC unavailable; no paper fill created');}
 checkPaperMint(account,change.decimals);
}
