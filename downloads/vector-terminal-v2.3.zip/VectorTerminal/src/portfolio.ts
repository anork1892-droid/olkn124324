import {db} from './store.ts';import {TARGET,WSOL} from './core.ts';import {mark,performance} from './analytics.ts';
export const portfolioHealth={updatedAt:null as string|null,error:null as string|null};
export async function chain(method:string,params:unknown[]){
 if(!process.env.SOLANA_RPC_URL)throw Error('Configure SOLANA_RPC_URL');
 const r=await fetch(process.env.SOLANA_RPC_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(12000)});
 if(!r.ok)throw Error('RPC HTTP '+r.status);const j=await r.json();if(j.error)throw Error('RPC error '+j.error.code);return j.result;
}
export async function inventory(wallet:string){
 const native=await chain('getBalance',[wallet,{commitment:'finalized'}]);if(!Number.isSafeInteger(native.value)||native.value<0)throw Error('Inexact native balance');
 const tokens=new Map<string,{mint:string;quantity:string;decimals:number;accounts:string[];program:string}>();
 for(const program of ['TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA','TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb']){
 const result=await chain('getTokenAccountsByOwner',[wallet,{programId:program},{encoding:'jsonParsed',commitment:'finalized',minContextSlot:native.context.slot}]);
 for(const row of result.value){const info=row.account.data.parsed.info;if(info.owner!==wallet)throw Error('Invalid account owner');const t=info.tokenAmount;if(!/^\d+$/.test(t.amount))throw Error('Invalid raw inventory');const old=tokens.get(info.mint);if(old&&old.decimals!==t.decimals)throw Error('Inconsistent decimals');tokens.set(info.mint,{mint:info.mint,quantity:String(BigInt(old?.quantity??'0')+BigInt(t.amount)),decimals:t.decimals,accounts:[...(old?.accounts??[]),row.pubkey],program});}
 }
 return {wallet,lamports:String(native.value),slot:native.context.slot,tokens:[...tokens.values()],observedAt:new Date().toISOString()};
}
let running=false;
export async function refreshPortfolio(){if(running)return;running=true;
 try{
 if(process.env.SOLANA_RPC_URL){const source=await inventory(TARGET);await db.query("INSERT INTO snapshots(kind,data) VALUES('source',$1)",[JSON.stringify(source)]);}
 const mode=(await db.query('SELECT value FROM config WHERE id=1')).rows[0].value.mode;
 const positions=(await db.query('SELECT * FROM positions WHERE mode=$1 AND quantity>0',[mode])).rows;
 const mints=[...new Set([WSOL,...positions.map(p=>p.mint)])];const prices:Record<string,any>={};
 const headers:Record<string,string>=process.env.JUPITER_API_KEY?{'x-api-key':process.env.JUPITER_API_KEY}:{};
 for(let offset=0;offset<mints.length;offset+=50){const r=await fetch('https://api.jup.ag/price/v3?ids='+encodeURIComponent(mints.slice(offset,offset+50).join(',')),{headers,signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('Price API HTTP '+r.status);Object.assign(prices,await r.json());}
 const metadata:Record<string,any>={};
 try{const r=await fetch('https://api.jup.ag/tokens/v2/search?query='+encodeURIComponent(mints.slice(0,100).join(',')),{headers,signal:AbortSignal.timeout(10000)});if(r.ok)for(const t of await r.json())metadata[t.id]=t;}catch{}
 const sol=prices[WSOL]?.usdPrice;let total=0n;const missing:string[]=[];const marked=positions.map(p=>{try{const v=mark(p.quantity,prices[p.mint]?.decimals,prices[p.mint]?.usdPrice,sol);total+=BigInt(v.lamports);return {...p,...v,name:metadata[p.mint]?.name??null,symbol:metadata[p.mint]?.symbol??null,icon:metadata[p.mint]?.icon??null,marketCapUsd:metadata[p.mint]?.mcap??null,unitUsd:prices[p.mint].usdPrice,decimals:prices[p.mint].decimals,unrealized:String(BigInt(v.lamports)-BigInt(p.cost))};}catch{missing.push(p.mint);return {...p,lamports:null,usd:null,unrealized:null};}});
 // Read cash and quantities under a shared snapshot; omit this observation if a fill changed inventory during HTTP requests.
 const c=await db.connect();try{await c.query('BEGIN ISOLATION LEVEL REPEATABLE READ');const current=(await c.query('SELECT mint,quantity,cost FROM positions WHERE mode=$1 AND quantity>0 ORDER BY mint COLLATE "C"',[mode])).rows;
 const expected=positions.map(p=>({mint:p.mint,quantity:p.quantity,cost:p.cost})).sort((a,b)=>a.mint<b.mint?-1:a.mint>b.mint?1:0);if(JSON.stringify(current)!==JSON.stringify(expected)){await c.query('ROLLBACK');return;}
 const cash=(await c.query('SELECT lamports FROM balances WHERE mode=$1',[mode])).rows[0].lamports;
 const value={positions:marked,cash,equityUsd:!missing.length&&Number.isFinite(sol)&&sol>0?mark(String(BigInt(cash)+total),9,sol,sol).usd:null,equity:missing.length?null:String(BigInt(cash)+total),missing,solUsd:sol??null,observedAt:new Date().toISOString(),estimated:true};
 await c.query('INSERT INTO snapshots(kind,data) VALUES($1,$2)',[mode,JSON.stringify(value)]);await c.query('COMMIT');}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 portfolioHealth.updatedAt=new Date().toISOString();portfolioHealth.error=null;
 }catch(e){portfolioHealth.error=e instanceof Error?e.message:'Portfolio refresh failed';}finally{running=false;}
}
export async function portfolioState(){
 const mode=(await db.query('SELECT value FROM config WHERE id=1')).rows[0].value.mode;
 const [source,paper,curve,sells]=await Promise.all([db.query("SELECT data FROM snapshots WHERE kind='source' ORDER BY id DESC LIMIT 1"),db.query('SELECT data FROM snapshots WHERE kind=$1 ORDER BY id DESC LIMIT 1',[mode]),db.query("SELECT data->>'equity' AS value,created AS at FROM (SELECT * FROM snapshots WHERE kind=$1 AND data->>'equity' IS NOT NULL ORDER BY id DESC LIMIT 2000) s ORDER BY id",[mode]),mode==='paper'?db.query("SELECT details->'fill'->>'realized' AS realized,details->'quote'->>'fee' AS fees,created AS at FROM paper_orders WHERE status='SIMULATED' AND details->>'side'='SELL'"):db.query("SELECT details->>'realized' AS realized,details->>'fee' AS fees,created AS at FROM live_orders WHERE status='CONFIRMED' AND details->'change'->>'side'='SELL'")]);
 return {mode,valuation:paper.rows[0]?.data??null,source:source.rows[0]?.data??null,paper:paper.rows[0]?.data??null,curve:curve.rows,performance:performance(curve.rows,sells.rows),health:portfolioHealth};
}
