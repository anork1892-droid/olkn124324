import {executeLive,reconcileLive} from './live-engine.ts';
import {executePaper} from './execution.ts';
import {JupiterQuotes} from './jupiter.ts';
import {db,log} from './store.ts';
import {classify,TARGET,type Transaction,percentage} from './core.ts';
let busy=false;
export const health={rpc:'unconfigured',lastPoll:null as string|null,error:null as string|null};
async function rpc(method:string,params:unknown[]){
 const endpoint=process.env.SOLANA_RPC_URL;if(!endpoint)throw Error('SOLANA_RPC_URL is not configured');
 const r=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(15000)});
 if(!r.ok)throw Error(`RPC HTTP ${r.status}`);const body=await r.json();if(body.error)throw Error(`RPC error ${body.error.code}`);return body.result;
}
export async function poll(){if(busy||!process.env.SOLANA_RPC_URL)return;busy=true;
 const leader=await db.connect();
 try{
 if(!(await leader.query('SELECT pg_try_advisory_lock(879024) AS acquired')).rows[0].acquired)return;
 await reconcileLive();
 const cursor=(await db.query('SELECT signature FROM cursor WHERE id=1')).rows[0]?.signature;
 const signatures:any[]=[];let before:string|undefined;let found=false;
 for(let page=0;page<20;page++){
  const rows=await rpc('getSignaturesForAddress',[TARGET,{limit:100,commitment:'finalized',...(before?{before}:{})}]);
  if(!cursor){if(rows[0])await db.query('INSERT INTO cursor VALUES(1,$1) ON CONFLICT(id) DO NOTHING',[rows[0].signature]);await log('Monitoring baseline set. Historical purchases will not be copied.');found=true;break;}
  for(const row of rows){if(row.signature===cursor){found=true;break;}signatures.push(row);}
  if(found||rows.length<100)break;before=rows.at(-1).signature;
 }
 if(cursor&&!found)throw Error('History gap: saved cursor unavailable within 2000 signatures. Copying halted pending reconciliation.');
 for(const row of signatures.reverse()){
  const tx=await rpc('getTransaction',[row.signature,{encoding:'jsonParsed',commitment:'finalized',maxSupportedTransactionVersion:0}]) as Transaction|null;
  if(!tx)throw Error('Finalized transaction temporarily unavailable');
  const parsed=classify(tx);const data=parsed.changes.map(c=>({...c,percentageSold:c.side==='SELL'?percentage(c.quantity,c.before):null}));
  const client=await db.connect();try{await client.query('BEGIN');
   const config=(await client.query('SELECT value FROM config WHERE id=1 FOR UPDATE')).rows[0].value;
   const reason=parsed.reason??(config.emergency?'Emergency stop':config.paused?'Copying paused':'Queued for paper quote');
   await client.query('INSERT INTO events(signature,slot,data,status,reason,mode,source_time) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING',[row.signature,row.slot,JSON.stringify(data,(_,v)=>typeof v==='bigint'?v.toString():v),parsed.reason||config.paused||config.emergency?'SKIPPED':'DETECTED',reason,config.mode,row.blockTime==null?null:new Date(row.blockTime*1000).toISOString()]);
   await client.query('UPDATE cursor SET signature=$1 WHERE id=1',[row.signature]);await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
 }
 await drainOrders();
 health.rpc='connected';health.lastPoll=new Date().toISOString();health.error=null;
 }catch(e){health.rpc='error';health.error=e instanceof Error?e.message:'Monitoring failed';await log(health.error);}finally{await leader.query('SELECT pg_advisory_unlock(879024)');leader.release();busy=false;}
}

export async function drainOrders(){
 const rows=(await db.query("SELECT signature,data,mode FROM events WHERE status='DETECTED' ORDER BY slot,created LIMIT 30")).rows;
 for(const event of rows){
  for(const raw of event.data){
   const change={...raw,before:BigInt(raw.before),after:BigInt(raw.after),quantity:BigInt(raw.quantity)};
   const key=event.signature+':'+raw.mint;
   const settings=(await db.query('SELECT value FROM config WHERE id=1')).rows[0].value;
   if(event.mode!==settings.mode){await db.query("UPDATE events SET status='SKIPPED',reason='Mode changed after detection' WHERE signature=$1",[event.signature]);continue;}
   if(event.mode==='live'){
    let status:string;try{status=await executeLive(key,change);}catch(e){const message=e instanceof Error?e.message.replace(/https?:\/\/\S+/g,'[provider]'):'Live preparation failed';await db.query("INSERT INTO live_orders(id,status,reason) VALUES($1,'SKIPPED',$2) ON CONFLICT DO NOTHING",[key,message]);status='SKIPPED';}
    const order=(await db.query('SELECT status,reason FROM live_orders WHERE id=$1',[key])).rows[0];await db.query('UPDATE events SET status=$1,reason=$2 WHERE signature=$3',[order?.status??(status==='WAITING'?'DETECTED':status),order?.reason??null,event.signature]);continue;
   }
   const status=await executePaper(db,new JupiterQuotes({priorityFeeLamports:BigInt(settings.priorityFeeLamports??'10000'),jitoTipLamports:BigInt(settings.jitoTipLamports??0),requireMarketCap:change.side==='BUY'&&(settings.minMarketCapUsd!=null||settings.maxMarketCapUsd!=null)}),key,change);
   const result=(await db.query('SELECT status,reason FROM paper_orders WHERE id=$1',[key])).rows[0];
   await db.query('UPDATE events SET status=$1,reason=$2 WHERE signature=$3',[result?.status??status,result?.reason??'Conservative simulated fill using current Jupiter V2 quote',event.signature]);
  }
 }
}
