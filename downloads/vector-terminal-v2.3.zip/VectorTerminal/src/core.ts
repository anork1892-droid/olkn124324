import {supportedSwap} from './source-protocols.ts';
export const TARGET='FZU56d9iPqohXM5XBrYYBZLi2UoUnZT4V5Qf2631tEzb';
export const TOKEN='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
export const TOKEN_2022='TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb';
export const WSOL='So11111111111111111111111111111111111111112';
export const JUPITER='JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4';
export type Balance={accountIndex:number;mint:string;owner?:string;programId?:string;uiTokenAmount:{amount:string;decimals:number}};
export type Transaction={meta:{preBalances?:number[];postBalances?:number[];err:unknown;preTokenBalances:Balance[];postTokenBalances:Balance[];fee:number;innerInstructions?:{instructions:{programId?:string;data?:string;parsed?:{type?:string}}[]}[]};transaction:{message:{accountKeys?:({pubkey:string;signer?:boolean}|string)[];instructions:{programId?:string;data?:string;parsed?:{type?:string}}[]}}};
export type Change={mint:string;tokenProgram?:string;before:bigint;after:bigint;quantity:bigint;decimals:number;side:'BUY'|'SELL';sourceSpent?:bigint;sourceReceived?:bigint;sourceBalance?:bigint};
export function percentage(n:bigint,d:bigint):string {if(d<=0n||n<0n||n>d)throw Error('Invalid fraction'); return `${n*10000n/d/100n}.${String(n*10000n/d%100n).padStart(2,'0')}`;}
export function sellAmount(ours:bigint,sold:bigint,before:bigint,strategy='exact',multiplierBps=10000):bigint {
 if(ours<0n||sold<0n||before<=0n||sold>before)throw Error('Inconsistent token quantities');
 if(strategy==='full'&&sold!==before)return 0n;
 const n=ours*sold*BigInt(strategy==='multiplier'?multiplierBps:10000)/(before*10000n);
 return n>ours?ours:n;
}
export function classify(tx:Transaction,wallet=TARGET):{changes:Change[];reason?:string} {
 if(!tx.meta||tx.meta.err)return {changes:[],reason:'Failed transaction'};
 const pre=tx.meta.preTokenBalances??[],post=tx.meta.postTokenBalances??[];
 const owned=new Set([...pre,...post].filter(b=>b.owner===wallet).map(b=>b.accountIndex));
 const entries=new Map<string,{before:bigint;after:bigint;decimals:number;tokenProgram?:string}>();
 for(const [phase,rows] of [['before',pre],['after',post]] as const)for(const b of rows){
  if(!owned.has(b.accountIndex))continue;
  if(b.owner&&b.owner!==wallet)return {changes:[],reason:'Token account ownership changed'};
  if(!/^\d+$/.test(b.uiTokenAmount.amount))return {changes:[],reason:'Invalid raw token amount'};
  const item=entries.get(b.mint)??{before:0n,after:0n,decimals:b.uiTokenAmount.decimals};
  if(item.decimals!==b.uiTokenAmount.decimals)return {changes:[],reason:'Inconsistent decimals'};
  if(b.programId&&item.tokenProgram&&b.programId!==item.tokenProgram)return {changes:[],reason:'Inconsistent token program for mint'};
  if(b.programId)item.tokenProgram=b.programId;
  item[phase]+=BigInt(b.uiTokenAmount.amount);entries.set(b.mint,item);
 }
 const changes=[...entries].filter(([,v])=>v.before!==v.after).map(([mint,v])=>({...v,mint,quantity:v.before>v.after?v.before-v.after:v.after-v.before,side:(v.before>v.after?'SELL':'BUY') as 'BUY'|'SELL'}));
 for(const c of changes)if(c.tokenProgram&&c.tokenProgram!==TOKEN&&c.tokenProgram!==TOKEN_2022)return {changes:[],reason:'Unsupported token program: '+c.tokenProgram};
 const instructions=[...tx.transaction.message.instructions,...(tx.meta.innerInstructions??[]).flatMap(i=>i.instructions)];
 if(!instructions.some(supportedSwap))return {changes:[],reason:'Transfer, liquidity operation or unsupported DEX: no recognized swap instruction'};
 if(tx.transaction.message.instructions.some(i=>(i.programId===TOKEN||i.programId===TOKEN_2022)&&(i.parsed?.type==='transfer'||i.parsed?.type==='transferChecked')))return {changes:[],reason:'Swap accompanied by a separate top-level transfer; ambiguous source inventory'};
 // Account for native SOL plus owned token-account lamports so ATA rent movements cancel.
 // This conservative classifier still rejects unsupported programs and ambiguous multi-asset changes.
 let quote=changes.find(c=>c.mint===WSOL);const tokens=changes.filter(c=>c.mint!==WSOL);
 const keys=tx.transaction.message.accountKeys;
 if(!quote&&keys&&tx.meta.preBalances&&tx.meta.postBalances){
  const index=keys.findIndex(k=>(typeof k==='string'?k:k.pubkey)===wallet);
  if(index>=0){
   const indices=new Set([...owned,index]);let before=0n,after=0n;
   for(const i of indices){
    const a=tx.meta.preBalances[i],b=tx.meta.postBalances[i];
    if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<0||b<0)return {changes:[],reason:'Native balances cannot be represented exactly'};
    before+=BigInt(a);after+=BigInt(b);
   }
   if(index===0){if(!Number.isSafeInteger(tx.meta.fee))return {changes:[],reason:'Invalid transaction fee'};after+=BigInt(tx.meta.fee);}
   if(before!==after)quote={mint:WSOL,before,after,quantity:before>after?before-after:after-before,decimals:9,side:before>after?'SELL':'BUY'};
  }
 }

 if(!quote||tokens.length!==1||quote.side===tokens[0].side)return {changes:[],reason:'Ambiguous swap balance changes; requires instruction-level decoding'};
 const c:Change=tokens[0];if(c.side==='SELL')c.sourceReceived=quote.quantity;if(c.side==='BUY'){c.sourceSpent=quote.quantity;const walletIndex=keys?.findIndex(k=>(typeof k==='string'?k:k.pubkey)===wallet)??-1;const balance=tx.meta.preBalances?.[walletIndex];if(balance!==undefined&&Number.isSafeInteger(balance)&&balance>0)c.sourceBalance=BigInt(balance);}
 return {changes:[c]};
}
export type Position={quantity:bigint;cost:bigint;realized:bigint};
export type Quote={input:bigint;output:bigint;fee:bigint;impactBps:number;observedAt:number;liquiditySol:number;marketCapUsd?:number};
export function paperFill(p:Position,cash:bigint,side:'BUY'|'SELL',q:Quote,now=Date.now()):{position:Position;cash:bigint;realized:bigint}{
 if(q.input<=0n||q.output<=0n||q.fee<0n||q.observedAt>now||now-q.observedAt>10000)throw Error('Invalid or stale executable quote');
 if(side==='BUY'){
  if(cash<q.input+q.fee)throw Error('Insufficient virtual SOL');
  return {position:{...p,quantity:p.quantity+q.output,cost:p.cost+q.input+q.fee},cash:cash-q.input-q.fee,realized:0n};
 }
 if(q.input>p.quantity||p.quantity===0n||q.output<q.fee)throw Error('Invalid sale');
 const basis=p.cost*q.input/p.quantity,realized=q.output-q.fee-basis;
 return {position:{quantity:p.quantity-q.input,cost:p.cost-basis,realized:p.realized+realized},cash:cash+q.output-q.fee,realized};
}
