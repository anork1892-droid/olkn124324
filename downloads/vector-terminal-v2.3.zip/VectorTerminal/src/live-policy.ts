import {routeAmounts} from './route-data.ts';
import {PublicKey,TransactionMessage,VersionedTransaction,type AddressLookupTableAccount} from '@solana/web3.js';
import {JUPITER,WSOL} from './core.ts';
export const TOKEN='TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
export const ATA='ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';
export const SYSTEM='11111111111111111111111111111111';
export const COMPUTE='ComputeBudget111111111111111111111111111111';
export function associated(owner:string,mint:string){return PublicKey.findProgramAddressSync([new PublicKey(owner).toBuffer(),new PublicKey(TOKEN).toBuffer(),new PublicKey(mint).toBuffer()],new PublicKey(ATA))[0];}
export type Intent={wallet:string;inputMint:string;outputMint:string;amount:bigint;minimumOutput:bigint;maxCost:bigint;priorityFee:bigint;jitoTip?:bigint;tipAccounts?:string[]};
export function validateMessage(tx:VersionedTransaction,intent:Intent,tables:AddressLookupTableAccount[]=[]){
 if(tx.version!==0)throw Error('Only version 0 swaps supported');
 const msg=TransactionMessage.decompile(tx.message,{addressLookupTableAccounts:tables});
 if(msg.payerKey.toBase58()!==intent.wallet||tx.message.header.numRequiredSignatures!==1)throw Error('Unexpected signer or fee payer');
 let routes=0,transfer=0n,tips=0n,unitPrice=0n,units=1400000n;
 const wsol=associated(intent.wallet,WSOL).toBase58();
 for(const ix of msg.instructions){const id=ix.programId.toBase58(),keys=ix.keys.map(k=>k.pubkey.toBase58()),data=Buffer.from(ix.data);
  if(id===JUPITER){routes++;const route=routeAmounts(data);const source=associated(intent.wallet,intent.inputMint).toBase58(),dest=associated(intent.wallet,intent.outputMint).toBase58();
   if(keys[0]!==TOKEN||route.amount!==intent.amount||route.minimum<intent.minimumOutput)throw Error('Encoded input or minimum output violates intent');
   if(route.shared){if(keys[2]!==intent.wallet||keys[3]!==source||keys[6]!==dest||keys[7]!==intent.inputMint||keys[8]!==intent.outputMint)throw Error('Unauthorized shared-route accounts');}
   else if(keys[1]!==intent.wallet||keys[2]!==source||keys[3]!==dest||![JUPITER,dest].includes(keys[4])||keys[5]!==intent.outputMint)throw Error('Unauthorized route accounts');continue;}
  if(id===COMPUTE){if(data[0]===2&&data.length===5){units=BigInt(data.readUInt32LE(1));if(units>1400000n)throw Error('Compute limit');}else if(data[0]===3&&data.length===9){unitPrice=data.readBigUInt64LE(1);}else throw Error('Unsupported compute instruction');continue;}
  if(id===SYSTEM){if(data.length!==12||data.readUInt32LE(0)!==2||keys[0]!==intent.wallet)throw Error('Unauthorized SOL transfer');if(keys[1]===wsol&&intent.inputMint===WSOL)transfer+=data.readBigUInt64LE(4);else if(intent.tipAccounts?.includes(keys[1]))tips+=data.readBigUInt64LE(4);else throw Error('Unauthorized SOL recipient');continue;}
  if(id===ATA){if(data.length>1||(data.length===1&&data[0]!==0&&data[0]!==1)||keys[0]!==intent.wallet||keys[2]!==intent.wallet||![intent.inputMint,intent.outputMint].includes(keys[3])||keys[1]!==associated(intent.wallet,keys[3]).toBase58()||keys[4]!==SYSTEM||keys[5]!==TOKEN)throw Error('Unauthorized associated account');continue;}
  if(id===TOKEN){if(data[0]===17&&data.length===1&&keys[0]===wsol)continue;if(data[0]===9&&data.length===1&&keys[0]===wsol&&keys[1]===intent.wallet&&keys[2]===intent.wallet)continue;throw Error('Token approval, transfer or authority change is not permitted');}
  throw Error('Unsupported top-level program');
 }
 if(routes!==1||transfer>intent.amount||tips>(intent.jitoTip??0n)||(units*unitPrice+999999n)/1000000n>intent.priorityFee)throw Error('Route or fee limits violated');
 return msg;
}
export type AccountSnapshot={address:string;lamports:bigint;program:string;data:Buffer}|null;
function token(a:AccountSnapshot,wallet:string){if(!a||a.program!==TOKEN)return null;if(a.data.length!==165)throw Error('Unsupported token account size');if(new PublicKey(a.data.subarray(32,64)).toBase58()!==wallet)throw Error('Token owner changed');if(a.data.readUInt32LE(72)!==0)throw Error('Delegated account not supported');if(a.data.readUInt32LE(129)!==0)throw Error('Close authority not supported');return {mint:new PublicKey(a.data.subarray(0,32)).toBase58(),amount:a.data.readBigUInt64LE(64)};}
export function validateSimulation(before:AccountSnapshot[],after:AccountSnapshot[],intent:Intent){
 if(before.length!==after.length||before.length===0)throw Error('Incomplete simulation');const changes=new Map<string,bigint>();let nativeBefore=0n,nativeAfter=0n;
 for(let i=0;i<before.length;i++){
  const a=before[i],b=after[i];nativeBefore+=a?.lamports??0n;nativeAfter+=b?.lamports??0n;
  if(i===0){if(!a||!b||a.program!==SYSTEM||b.program!==SYSTEM||b.data.length)throw Error('Wallet account altered');continue;}
  const old=token(a,intent.wallet),next=token(b,intent.wallet);if(old&&next&&old.mint!==next.mint)throw Error('Account mint changed');
  if(a&&a.program!==TOKEN||b&&b.program!==TOKEN)throw Error('Account program altered');
  if(old)changes.set(old.mint,(changes.get(old.mint)??0n)-old.amount);if(next)changes.set(next.mint,(changes.get(next.mint)??0n)+next.amount);
 }
 // Native sum includes token-account rent and wSOL backing. Do not count wSOL twice.
 changes.set(WSOL,nativeAfter-nativeBefore);
 for(const [mint,delta] of changes){if(mint!==intent.inputMint&&mint!==intent.outputMint&&delta!==0n)throw Error('Unrelated asset movement');}
 const spent=-(changes.get(intent.inputMint)??0n),received=changes.get(intent.outputMint)??0n;
 if(intent.inputMint===WSOL){if(spent<intent.amount||spent>intent.amount+intent.maxCost)throw Error('Native debit exceeds authorized input and fees');if(received<intent.minimumOutput)throw Error('Output below minimum');}
 else{if(spent!==intent.amount||received+intent.maxCost<intent.minimumOutput)throw Error('Token input or SOL output violates policy');}
 return {spent,received};
}
