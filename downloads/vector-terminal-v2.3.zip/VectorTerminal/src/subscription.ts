import {TARGET} from './core.ts';
export function subscribe(wake:()=>Promise<void>){
 const endpoint=process.env.SOLANA_WS_URL;if(!endpoint)return ()=>{};
 let stopped=false,socket:WebSocket|undefined,retry:ReturnType<typeof setTimeout>|undefined,delay=1000;
 function connect(){if(stopped)return;try{
  socket=new WebSocket(endpoint!);const current=socket;
  const timeout=setTimeout(()=>current.close(),15000);
  current.addEventListener('open',()=>{clearTimeout(timeout);delay=1000;current.send(JSON.stringify({jsonrpc:'2.0',id:1,method:'logsSubscribe',params:[{mentions:[TARGET]},{commitment:'finalized'}]}));});
  current.addEventListener('message',event=>{try{const msg=JSON.parse(String(event.data));if(msg.method==='logsNotification')void wake();if(msg.error)current.close();}catch{current.close();}});
  current.addEventListener('error',()=>current.close());
  current.addEventListener('close',()=>{clearTimeout(timeout);if(!stopped){retry=setTimeout(connect,delay);delay=Math.min(delay*2,30000);}});
 }catch{if(!stopped)retry=setTimeout(connect,30000);}}
 connect();return ()=>{stopped=true;if(retry)clearTimeout(retry);socket?.close();};
}
