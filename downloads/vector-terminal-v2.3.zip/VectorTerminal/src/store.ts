import pg from 'pg';
export const db=new pg.Pool({connectionString:process.env.DATABASE_URL??'postgresql://postgres@127.0.0.1:5433/terminal'});
export async function initialize(){await db.query(`
CREATE TABLE IF NOT EXISTS provider_settings(id int PRIMARY KEY CHECK(id=1),payload text NOT NULL);
CREATE TABLE IF NOT EXISTS config(id int PRIMARY KEY CHECK(id=1), value jsonb NOT NULL);
INSERT INTO config VALUES(1,'{"mode":"paper","paused":true,"emergency":false,"fixedLamports":"100000000","maxPerTokenLamports":"1000000000","reserveLamports":"500000000","sellStrategy":"exact","multiplierBps":10000,"additionalBuys":true,"slippageBps":100,"maxImpactBps":200,"minLiquiditySol":10,"maxPositions":10}') ON CONFLICT DO NOTHING;
UPDATE config SET value='{"paperSellImpactBps":null,"quoteRetries":1,"confirmationTimeoutMs":30000,"jitoTipLamports":"0","buySizing":"fixed","balanceBps":1000,"maxTradeLamports":"1000000000","minMarketCapUsd":null,"maxMarketCapUsd":null,"priorityFeeLamports":"10000","maxCostLamports":"5000000","dailyLossLamports":"1000000000","executionDelayMs":750,"blacklist":[]}'::jsonb || value WHERE id=1;
CREATE TABLE IF NOT EXISTS events(signature text PRIMARY KEY, slot bigint NOT NULL, data jsonb NOT NULL,status text NOT NULL,reason text,created timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS positions(mode text NOT NULL,mint text NOT NULL,quantity numeric(78,0) NOT NULL,cost numeric(78,0) NOT NULL,realized numeric(78,0) NOT NULL,PRIMARY KEY(mode,mint));
CREATE TABLE IF NOT EXISTS balances(mode text PRIMARY KEY,lamports numeric(78,0) NOT NULL);
INSERT INTO balances VALUES('paper',10000000000) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS audit(id bigserial PRIMARY KEY,created timestamptz DEFAULT now(),message text NOT NULL);
CREATE TABLE IF NOT EXISTS paper_orders(id text PRIMARY KEY,status text NOT NULL,reason text,details jsonb,created timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS snapshots(id bigserial PRIMARY KEY,kind text NOT NULL,data jsonb NOT NULL,created timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS snapshots_kind_id ON snapshots(kind,id DESC);
CREATE TABLE IF NOT EXISTS live_orders(id text PRIMARY KEY,status text NOT NULL,signature text UNIQUE,prepared jsonb,details jsonb,reason text,created timestamptz NOT NULL DEFAULT now());
ALTER TABLE events ADD COLUMN IF NOT EXISTS mode text NOT NULL DEFAULT 'paper';
ALTER TABLE events ADD COLUMN IF NOT EXISTS source_time timestamptz;
CREATE TABLE IF NOT EXISTS target_history(signature text PRIMARY KEY,slot bigint NOT NULL,data jsonb NOT NULL,created timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS cursor(id int PRIMARY KEY,signature text NOT NULL);
`);}
export async function log(message:string){await db.query('INSERT INTO audit(message) VALUES($1)',[message]);}
export async function state(){const c=await db.query('SELECT value FROM config WHERE id=1');const mode=c.rows[0].value.mode;const [e,p,b,l,o,live,stats]=await Promise.all([db.query("SELECT * FROM events WHERE EXISTS (SELECT 1 FROM jsonb_array_elements(data) c WHERE c->>'side' IN ('BUY','SELL')) ORDER BY slot DESC,created DESC LIMIT 100"),db.query('SELECT * FROM positions WHERE mode=$1',[mode]),db.query('SELECT lamports FROM balances WHERE mode=$1',[mode]),db.query('SELECT * FROM audit ORDER BY id DESC LIMIT 100'),db.query('SELECT * FROM paper_orders ORDER BY created DESC LIMIT 200'),db.query('SELECT id,status,signature,details,reason,created FROM live_orders ORDER BY created DESC LIMIT 200'),db.query(mode==='paper'?"SELECT count(*)::text AS copied,COALESCE(sum((details->'fill'->>'realized')::numeric),0)::text AS realized,COALESCE(sum((details->'fill'->>'realized')::numeric) FILTER(WHERE created >= date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'),0)::text AS today,COALESCE(sum((details->'quote'->>'fee')::numeric),0)::text AS fees FROM paper_orders WHERE status='SIMULATED'":"SELECT count(*) FILTER(WHERE status='CONFIRMED')::text AS copied,COALESCE(sum((details->>'realized')::numeric),0)::text AS realized,COALESCE(sum((details->>'realized')::numeric) FILTER(WHERE created >= date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'),0)::text AS today,COALESCE(sum((details->>'fee')::numeric),0)::text AS fees FROM live_orders WHERE status IN ('CONFIRMED','FAILED')")]);return {settings:c.rows[0].value,events:e.rows,positions:p.rows,balance:b.rows[0]?.lamports??'0',logs:l.rows,orders:o.rows,liveOrders:live.rows,statistics:stats.rows[0]};}
