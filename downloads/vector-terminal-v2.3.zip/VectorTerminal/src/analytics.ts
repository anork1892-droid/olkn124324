import {Decimal} from 'decimal.js';
Decimal.set({precision:80,rounding:Decimal.ROUND_DOWN});
export function mark(quantity:string,decimals:number,usdPrice:number|string,solUsd:number|string){
 if(!/^\d+$/.test(quantity)||!Number.isInteger(decimals)||decimals<0||decimals>18)throw Error('Invalid token inventory');
 const price=new Decimal(usdPrice),sol=new Decimal(solUsd);if(!price.isFinite()||price.lte(0)||!sol.isFinite()||sol.lte(0))throw Error('Price unavailable');
 const usd=new Decimal(quantity).div(new Decimal(10).pow(decimals)).mul(price);
 return {usd:usd.toFixed(8),lamports:usd.div(sol).mul(1e9).floor().toFixed(0)};
}
export function performance(equity:{value:string;at:string}[],orders:{realized:string;fees:string;at:string}[]){
 let peak=0n,maxDrawdownBps=0n;for(const p of equity){const n=BigInt(p.value);if(n>peak)peak=n;if(peak>0n){const dd=(peak-n)*10000n/peak;if(dd>maxDrawdownBps)maxDrawdownBps=dd;}}
 const realized=orders.reduce((n,o)=>n+BigInt(o.realized),0n),fees=orders.reduce((n,o)=>n+BigInt(o.fees),0n);const wins=orders.filter(o=>BigInt(o.realized)>0n).length;
 return {realized:String(realized),estimatedFees:String(fees),winRate:orders.length?wins/orders.length:null,averageProfit:orders.length?String(realized/BigInt(orders.length)):null,maxDrawdownBps:equity.length?Number(maxDrawdownBps):null};
}
