// Schema: jup-ag/jupiter-cpi commit 12bc5f67b94a2c3edc74d6e721a19442124a0bad.
// Unknown variants are rejected rather than interpreted using guessed offsets.
import {createHash} from 'node:crypto';import schema from './jupiter-route-types.json' with {type:'json'};
const types=new Map<string,any>(schema.map(t=>[t.name,t.type]));
const discriminator=(name:string)=>createHash('sha256').update('global:'+name).digest().subarray(0,8);
export function routeAmounts(data:Buffer){
 let shared=false;if(data.subarray(0,8).equals(discriminator('shared_accounts_route')))shared=true;else if(!data.subarray(0,8).equals(discriminator('route')))throw Error('Unsupported Jupiter route instruction');
 let offset=shared?9:8;
 function take(n:number){if(n<0||offset+n>data.length)throw Error('Truncated route data');const old=offset;offset+=n;return old;}
 function consume(t:any,depth=0){if(depth>10)throw Error('Nested route type limit');
  const sizes:Record<string,number>={bool:1,u8:1,i8:1,u16:2,i16:2,u32:4,i32:4,u64:8,i64:8,u128:16,i128:16,publicKey:32};
  if(typeof t==='string'){if(!sizes[t])throw Error('Unknown route scalar');const at=take(sizes[t]);if(t==='bool'&&data[at]>1)throw Error('Invalid boolean');return;}
  if(t.defined){const definition=types.get(t.defined);if(!definition)throw Error('Unknown route type');if(definition.kind==='struct'){for(const f of definition.fields)consume(f.type,depth+1);return;}if(definition.kind==='enum'){const variant=definition.variants[data[take(1)]];if(!variant)throw Error('Unsupported swap enum');for(const f of variant.fields??[])consume(f.type??f,depth+1);return;}}
  if(t.array){if(t.array[1]>64)throw Error('Route array limit');for(let n=0;n<t.array[1];n++)consume(t.array[0],depth+1);return;}
  throw Error('Unsupported route layout');
 }
 const count=data.readUInt32LE(take(4));if(count<1||count>20)throw Error('Route hop limit');for(let n=0;n<count;n++)consume({defined:'RoutePlanStep'});
 if(offset+19!==data.length)throw Error('Ambiguous trailing route data');const amount=data.readBigUInt64LE(take(8)),quoted=data.readBigUInt64LE(take(8)),slippage=data.readUInt16LE(take(2)),fee=data[take(1)];if(slippage>10000)throw Error('Invalid encoded slippage');
 return {shared,amount,minimum:quoted*BigInt(10000-slippage)/10000n*BigInt(10000-fee)/10000n};
}
