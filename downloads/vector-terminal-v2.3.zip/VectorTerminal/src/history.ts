import {db} from './store.ts';import {chain} from './portfolio.ts';import {TARGET,classify} from './core.ts';
export function reconstructedCycles(events:{changes:any[];fee:string}[]){
 const active=new Map<string,{balance:bigint;spent:bigint;received:bigint;fees:bigint;valid:boolean}>();const closed:{mint:string;netLamports:string}[]=[];
 for(const event of events){if(!event.changes.length){for(const p of active.values())p.valid=false;}for(const c of event.changes){const before=BigInt(c.before),after=BigInt(c.after);let p=active.get(c.mint);
  if(c.side==='BUY'&&before===0n)p={balance:0n,spent:0n,received:0n,fees:0n,valid:true};
  if(!p)continue;if(p.balance!==before)p.valid=false;p.balance=after;p.fees+=BigInt(event.fee);
  if(c.side==='BUY'){if(c.sourceSpent==null)p.valid=false;else p.spent+=BigInt(c.sourceSpent);}
  else{if(c.sourceReceived==null)p.valid=false;else p.received+=BigInt(c.sourceReceived);}
  if(after===0n){if(p.valid)closed.push({mint:c.mint,netLamports:String(p.received-p.spent-p.fees)});active.delete(c.mint);}else active.set(c.mint,p);
 }}
 return {closed,netLamports:String(closed.reduce((n,p)=>n+BigInt(p.netLamports),0n)),scope:'Only observed zero-to-zero cycles with consistent quantities; not lifetime wallet profit'};
}
let fetching=false;
export async function backfillHistory(){if(fetching)throw Error('Historical import already running');fetching=true;try{
 const cursor=(await db.query('SELECT signature FROM target_history ORDER BY slot ASC,created ASC LIMIT 1')).rows[0]?.signature;
 const rows=await chain('getSignaturesForAddress',[TARGET,{limit:20,commitment:'finalized',...(cursor?{before:cursor}:{})}]);const records:{signature:string;slot:number;data:string}[]=[];
 for(const row of [...rows].reverse()){
  const tx=await chain('getTransaction',[row.signature,{encoding:'jsonParsed',commitment:'finalized',maxSupportedTransactionVersion:0}]);if(!tx)throw Error('Archived transaction unavailable');const result=classify(tx);
  const first=tx.transaction.message.accountKeys?.[0];const payer=typeof first==='string'?first:first?.pubkey;
  const data={changes:result.changes,fee:String(payer===TARGET?tx.meta.fee:0),time:row.blockTime==null?null:new Date(row.blockTime*1000).toISOString(),reason:result.reason??null};
  records.push({signature:row.signature,slot:row.slot,data:JSON.stringify(data,(_,v)=>typeof v==='bigint'?String(v):v)});
 }
 const c=await db.connect();let count=0;try{await c.query('BEGIN');for(const r of records)count+=(await c.query('INSERT INTO target_history(signature,slot,data) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',[r.signature,r.slot,r.data])).rowCount??0;await c.query('COMMIT');}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
 return {imported:count,readOnly:true};
 }finally{fetching=false;}}
export async function historyState(){const rows=(await db.query('SELECT signature,slot,data FROM target_history ORDER BY slot,created LIMIT 5000')).rows;return {events:rows.slice(-100).reverse(),summary:reconstructedCycles(rows.map(r=>r.data)),limited:rows.length===5000};}
