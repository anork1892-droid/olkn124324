import {validatePaperMint} from './token-policy.ts';
import {buySize} from './risk.ts';
import type {Pool} from 'pg';
import {paperFill,sellAmount,type Change,type Quote} from './core.ts';
// The paper engine accepts quote data only. It has no signer or submission dependency.
export interface Quotes {quote(mint:string,side:'BUY'|'SELL',amount:bigint,slippageBps:number):Promise<Quote>}
export async function executePaper(pool:Pool,quotes:Quotes,key:string,change:Change,options:{closePosition?:boolean}={}){
 const c=await pool.connect();try{await c.query('BEGIN');
 // Serialize paper accounting on the balance row; controls remain responsive during network I/O.
 const s=(await c.query('SELECT value FROM config WHERE id=1')).rows[0].value;
 const cash=BigInt((await c.query("SELECT lamports FROM balances WHERE mode='paper' FOR UPDATE")).rows[0].lamports);
 await c.query(`CREATE TABLE IF NOT EXISTS paper_orders(id text PRIMARY KEY,status text NOT NULL,reason text,details jsonb,created timestamptz DEFAULT now())`);
 if((await c.query('SELECT id FROM paper_orders WHERE id=$1',[key])).rowCount){await c.query('ROLLBACK');return 'DUPLICATE';}
 const skip=async(reason:string,status='SKIPPED')=>{await c.query('INSERT INTO paper_orders(id,status,reason) VALUES($1,$2,$3)',[key,status,reason]);await c.query('COMMIT');return status;};
 if(s.emergency||s.paused)return await skip('Copying stopped or paused');
 if(s.blacklist?.includes(change.mint))return await skip('Token blacklisted');
 const daily=(await c.query("SELECT COALESCE(sum((details->'fill'->>'realized')::numeric),0)::text AS realized FROM paper_orders WHERE status='SIMULATED' AND created>=date_trunc('day',now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC'")).rows[0].realized;
 if(change.side==='BUY'&&BigInt(daily)<=-BigInt(s.dailyLossLamports??'1000000000'))return await skip('Maximum daily realized loss');
 if(s.mode!=='paper')return await skip('Paper engine refuses live mode');
 const row=(await c.query("SELECT * FROM positions WHERE mode='paper' AND mint=$1 FOR UPDATE",[change.mint])).rows[0];
 const p={quantity:BigInt(row?.quantity??0),cost:BigInt(row?.cost??0),realized:BigInt(row?.realized??0)};
 let amount:bigint;
 if(change.side==='SELL'){
  if(p.quantity===0n)return await skip('No copied holding');
  amount=options.closePosition?p.quantity:sellAmount(p.quantity,change.quantity,change.before,s.sellStrategy,s.multiplierBps);
  if(amount===0n)return await skip('Sell strategy excludes partial exit or amount rounds to zero');
 }else{
  if(p.quantity>0n&&!s.additionalBuys)return await skip('Additional buys disabled');
  const count=Number((await c.query("SELECT count(*) FROM positions WHERE mode='paper' AND quantity>0")).rows[0].count);
  if(p.quantity===0n&&count>=s.maxPositions)return await skip('Maximum positions reached');
  try{amount=buySize(s,cash,change.sourceSpent,change.sourceBalance);}catch(e){return await skip(e instanceof Error?e.message:'Sizing unavailable');}
  if(p.cost+amount>BigInt(s.maxPerTokenLamports))return await skip('Token allocation limit');
 }
 try{await validatePaperMint(change);}catch(e){return await skip(e instanceof Error?e.message:'Mint policy verification failed');}
 if(s.executionDelayMs)await new Promise(resolve=>setTimeout(resolve,s.executionDelayMs));
 let q:Quote|undefined;for(let attempt=0;attempt<=(s.quoteRetries??0);attempt++){try{q=await quotes.quote(change.mint,change.side,amount,s.slippageBps);break;}catch{if(attempt<(s.quoteRetries??0))await new Promise(r=>setTimeout(r,500*(2**attempt)));}}if(!q)return await skip('Executable quote unavailable after configured retries','UNPRICEABLE');
 const current=(await c.query('SELECT value FROM config WHERE id=1 FOR UPDATE')).rows[0].value;
 if(current.emergency||current.paused||JSON.stringify(current)!==JSON.stringify(s))return await skip('Stopped or settings changed while quoting');
 if(q.fee>BigInt(s.maxCostLamports??'1000000'))return await skip('Estimated transaction cost exceeds limit');
 if(change.side==='BUY'&&(s.minMarketCapUsd!=null||s.maxMarketCapUsd!=null)&&(!Number.isFinite(q.marketCapUsd)||(s.minMarketCapUsd!=null&&q.marketCapUsd!<s.minMarketCapUsd)||(s.maxMarketCapUsd!=null&&q.marketCapUsd!>s.maxMarketCapUsd)))return await skip('Market-cap filter or missing market-cap data');
 if(q.input!==amount)return await skip('Quote input mismatch');
 if(!Number.isFinite(q.impactBps)||q.impactBps<0)return await skip('Invalid quoted price impact');
 const impactLimit=change.side==='SELL'?(s.paperSellImpactBps??null):s.maxImpactBps;
 if(impactLimit!=null&&q.impactBps>impactLimit)return await skip(`${change.side} price impact ${(q.impactBps/100).toFixed(2)}% exceeds ${(impactLimit/100).toFixed(2)}% limit`);
 if(!Number.isFinite(q.liquiditySol)||q.liquiditySol<s.minLiquiditySol)return await skip('Insufficient verified liquidity');
 if(change.side==='BUY'&&(cash-amount-q.fee<BigInt(s.reserveLamports)||p.cost+amount+q.fee>BigInt(s.maxPerTokenLamports)))return await skip('Reserve or allocation including fees exceeded');
 let fill;try{fill=paperFill(p,cash,change.side,q);}catch{return await skip('Invalid fill or stale quote','UNPRICEABLE');}
 await c.query("INSERT INTO positions(mode,mint,quantity,cost,realized) VALUES('paper',$1,$2,$3,$4) ON CONFLICT(mode,mint) DO UPDATE SET quantity=EXCLUDED.quantity,cost=EXCLUDED.cost,realized=EXCLUDED.realized",[change.mint,String(fill.position.quantity),String(fill.position.cost),String(fill.position.realized)]);
 await c.query("UPDATE balances SET lamports=$1 WHERE mode='paper'",[String(fill.cash)]);
 await c.query('INSERT INTO paper_orders(id,status,details) VALUES($1,$2,$3)',[key,'SIMULATED',JSON.stringify({mint:change.mint,side:change.side,manualClose:options.closePosition??false,quote:q,fill},(_,v)=>typeof v==='bigint'?String(v):v)]);
 await c.query('COMMIT');return 'SIMULATED';
 }catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}
}
