import {WSOL,type Quote} from './core.ts';
import type {Quotes} from './execution.ts';
export type Fetcher=typeof fetch;
export class JupiterQuotes implements Quotes {
 private request:Fetcher; private apiKey:string; private fees:bigint;private requireMarketCap:boolean;
 constructor(options:{fetcher?:Fetcher;apiKey?:string;priorityFeeLamports?:bigint;jitoTipLamports?:bigint;requireMarketCap?:boolean}={}){this.requireMarketCap=options.requireMarketCap??false;this.request=options.fetcher??fetch;this.apiKey=options.apiKey??process.env.JUPITER_API_KEY??'';this.fees=(options.priorityFeeLamports??10000n)+(options.jitoTipLamports??0n);}
 async quote(mint:string,side:'BUY'|'SELL',amount:bigint,slippageBps:number):Promise<Quote>{
  const inputMint=side==='BUY'?WSOL:mint,outputMint=side==='BUY'?mint:WSOL;
  const headers:Record<string,string>=this.apiKey?{'x-api-key':this.apiKey}:{};
  const url='https://api.jup.ag/swap/v2/order?'+new URLSearchParams({inputMint,outputMint,amount:String(amount),slippageBps:String(slippageBps)});
  // No taker is sent and no transaction can be signed by this adapter.
  const started=Date.now();
  const [order,prices]=await Promise.all([this.request(url,{headers,signal:AbortSignal.timeout(8000)}),this.request('https://api.jup.ag/price/v3?ids='+encodeURIComponent(mint+','+WSOL),{headers,signal:AbortSignal.timeout(8000)})]);
  if(!order.ok||!prices.ok)throw Error(`Jupiter quote/price HTTP ${order.status}/${prices.status}`);
  const q=await order.json(),p=await prices.json();
  if(q.errorCode||q.error||q.inputMint!==inputMint||q.outputMint!==outputMint||q.inAmount!==String(amount)||q.swapMode!=='ExactIn'||!/^\d+$/.test(q.outAmount)||!/^\d+$/.test(q.otherAmountThreshold))throw Error('Invalid or unavailable Jupiter route');
  if(!Number.isFinite(q.priceImpact)||!Number.isInteger(q.slippageBps)||q.slippageBps>slippageBps)throw Error('Invalid quote impact/slippage');
  const minimum=BigInt(q.otherAmountThreshold),out=BigInt(q.outAmount);
  if(minimum<=0n||minimum>out||minimum<out*BigInt(10000-slippageBps)/10000n)throw Error('Quote exceeds slippage policy');
  const liquidity=p[mint]?.liquidity,sol=p[WSOL]?.usdPrice;
  if(!Number.isFinite(liquidity)||liquidity<0||!Number.isFinite(sol)||sol<=0)throw Error('Reliable liquidity or SOL price unavailable');
  // Conservative paper fill at minimum output. Swap/platform fees are already reflected in route output.
  // Base+configured priority fee are explicit estimates; no custom Jito tip is assumed.
  let marketCapUsd:number|undefined;
  if(this.requireMarketCap){const r=await this.request('https://api.jup.ag/tokens/v2/search?query='+encodeURIComponent(mint),{headers,signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Token metadata unavailable');const rows=await r.json();const token=rows.find((t:any)=>t.id===mint);if(!Number.isFinite(token?.mcap)||token.mcap<=0)throw Error('Reliable market cap unavailable');marketCapUsd=token.mcap;}
  return {marketCapUsd,input:amount,output:minimum,fee:5000n+this.fees,impactBps:Math.ceil(Math.abs(q.priceImpact)*100),observedAt:started,liquiditySol:liquidity/sol};
 }
}
