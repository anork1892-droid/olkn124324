export function buySize(settings:any,cash:bigint,sourceSpent?:string|bigint,sourceBalance?:string|bigint){
 const available=cash-BigInt(settings.reserveLamports)-BigInt(settings.maxCostLamports??'1000000');if(available<=0n)throw Error('No trading balance after reserve');
 let amount:bigint;
 if(settings.buySizing==='balance')amount=available*BigInt(settings.balanceBps)/10000n;
 else if(settings.buySizing==='proportional'){if(sourceSpent===undefined||sourceBalance===undefined||BigInt(sourceBalance)<=0n||BigInt(sourceSpent)>BigInt(sourceBalance))throw Error('Reliable source SOL allocation is unavailable');amount=available*BigInt(sourceSpent)/BigInt(sourceBalance);}
 else amount=BigInt(settings.fixedLamports);
 const cap=BigInt(settings.maxTradeLamports??settings.fixedLamports);amount=amount>cap?cap:amount;if(amount<=0n||amount>available)throw Error('Trade exceeds available balance');return amount;
}
