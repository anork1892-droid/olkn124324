import {readFile} from 'node:fs/promises';import {Connection,Keypair,PublicKey,VersionedTransaction} from '@solana/web3.js';import bs58 from 'bs58';
import {WSOL} from './core.ts';import {associated,validateMessage,validateSimulation,TOKEN,type Intent,type AccountSnapshot} from './live-policy.ts';
export class LiveAdapter {
 private signer:Keypair; private connection:Connection; private request:typeof fetch;
 constructor(signer:Keypair,connection:Connection,request:typeof fetch=fetch){this.signer=signer;this.connection=connection;this.request=request;}
 get wallet(){return this.signer.publicKey.toBase58();}
 static async configured(){
  if(process.env.ENABLE_LIVE_TRADING!=='true'||!process.env.LIVE_KEYPAIR_FILE||!process.env.SOLANA_RPC_URL)throw Error('Live wallet is not explicitly enabled in backend configuration');
  const raw=JSON.parse(await readFile(process.env.LIVE_KEYPAIR_FILE,'utf8'));if(!Array.isArray(raw)||raw.length!==64||raw.some(n=>!Number.isInteger(n)||n<0||n>255))throw Error('Invalid Solana keypair file');
  return new LiveAdapter(Keypair.fromSecretKey(Uint8Array.from(raw)),new Connection(process.env.SOLANA_RPC_URL,'confirmed'));
 }
 private headers():Record<string,string>{return process.env.JUPITER_API_KEY?{'x-api-key':process.env.JUPITER_API_KEY}:{};}
 async prepare(intent:Intent,slippageBps:number){
  if(intent.wallet!==this.wallet||intent.amount<=0n)throw Error('Unauthorized wallet');
  const query=new URLSearchParams({inputMint:intent.inputMint,outputMint:intent.outputMint,amount:String(intent.amount),taker:this.wallet,slippageBps:String(slippageBps),priorityFeeLamports:String(intent.priorityFee),jitoTipLamports:String(intent.jitoTip??0n),broadcastFeeType:'exactFee',excludeRouters:'jupiterz,dflow,okx',maxSupportedTransactionVersion:'0'});
  const response=await this.request('https://api.jup.ag/swap/v2/order?'+query,{headers:this.headers(),signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('Jupiter order HTTP '+response.status);const q=await response.json();
  if(q.errorCode||q.error||q.router!=='metis'||q.inputMint!==intent.inputMint||q.outputMint!==intent.outputMint||q.inAmount!==String(intent.amount)||q.swapMode!=='ExactIn'||q.gasless||q.signatureFeePayer!==this.wallet||typeof q.transaction!=='string'||!q.transaction||q.transaction.length>4000||typeof q.requestId!=='string')throw Error('Unexpected managed swap response');
  if(!/^\d+$/.test(q.otherAmountThreshold)||BigInt(q.otherAmountThreshold)<intent.minimumOutput||!Number.isInteger(q.slippageBps)||q.slippageBps>slippageBps)throw Error('Swap quote violates slippage policy');
  const fees=[q.signatureFeeLamports,q.prioritizationFeeLamports,q.rentFeeLamports];if(fees.some(n=>!Number.isSafeInteger(n)||n<0)||fees.reduce((a,b)=>a+BigInt(b),0n)>intent.maxCost)throw Error('Fee or rent cap exceeded');
  const tx=VersionedTransaction.deserialize(Buffer.from(q.transaction,'base64'));
  const tables=[];for(const lookup of tx.message.addressTableLookups){const result=await this.connection.getAddressLookupTable(lookup.accountKey);if(!result.value)throw Error('Address lookup table unavailable');tables.push(result.value);}
  if((intent.jitoTip??0n)>0n){const r=await this.request('https://mainnet.block-engine.jito.wtf/api/v1/bundles',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'getTipAccounts',params:[]}),signal:AbortSignal.timeout(8000)});if(!r.ok)throw Error('Jito tip recipients unavailable');const result=await r.json();if(!Array.isArray(result.result)||!result.result.length||result.result.some((a:unknown)=>typeof a!=='string'))throw Error('Invalid Jito account response');intent={...intent,tipAccounts:result.result};}
  validateMessage(tx,intent,tables);
  const unsupported=await this.connection.getTokenAccountsByOwner(this.signer.publicKey,{programId:new PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb')});if(unsupported.value.length)throw Error('Token-2022 accounts require an unsupported simulation policy');
  const owned=await this.connection.getTokenAccountsByOwner(this.signer.publicKey,{programId:new PublicKey(TOKEN)});
  const addresses=[this.signer.publicKey,...owned.value.map(a=>a.pubkey),associated(this.wallet,intent.inputMint),associated(this.wallet,intent.outputMint)];const unique=[...new Map(addresses.map(a=>[a.toBase58(),a])).values()];
  if(unique.length>90)throw Error('Wallet has too many accounts for exhaustive simulation');
  const pre=await this.connection.getMultipleAccountsInfo(unique,'confirmed');
  const simulation=await this.connection.simulateTransaction(tx,{sigVerify:false,replaceRecentBlockhash:true,commitment:'confirmed',accounts:{encoding:'base64',addresses:unique.map(a=>a.toBase58())}});
  if(simulation.value.err||!simulation.value.accounts||simulation.value.accounts.length!==unique.length)throw Error('Swap simulation failed or incomplete');
  function account(a:any,i:number,encoded=false):AccountSnapshot{if(!a)return null;if(!Number.isSafeInteger(a.lamports)||a.lamports<0)throw Error('Inexact simulated lamports');return {address:unique[i].toBase58(),lamports:BigInt(a.lamports),program:typeof a.owner==='string'?a.owner:a.owner.toBase58(),data:encoded?Buffer.from(a.data[0],'base64'):a.data};}
  validateSimulation(pre.map((a,i)=>account(a,i)),simulation.value.accounts.map((a,i)=>account(a,i,true)),intent);
  tx.sign([this.signer]);return {signedTransaction:Buffer.from(tx.serialize()).toString('base64'),signature:bs58.encode(tx.signatures[0]),requestId:q.requestId,preparedAt:Date.now(),intent:{...intent,amount:String(intent.amount),minimumOutput:String(intent.minimumOutput),maxCost:String(intent.maxCost),priorityFee:String(intent.priorityFee),jitoTip:String(intent.jitoTip??0n)}};
 }
 async send(prepared:{signedTransaction:string;requestId:string},timeoutMs=30000){
  const r=await this.request('https://api.jup.ag/swap/v2/execute',{method:'POST',headers:{...this.headers(),'Content-Type':'application/json'},body:JSON.stringify({signedTransaction:prepared.signedTransaction,requestId:prepared.requestId}),signal:AbortSignal.timeout(timeoutMs)});
  if(!r.ok)throw Error('Managed execute outcome unknown; reconcile the persisted signature');return r.json();
 }
 async status(signature:string){const r=await this.connection.getSignatureStatuses([signature],{searchTransactionHistory:true});return r.value[0];}
}
