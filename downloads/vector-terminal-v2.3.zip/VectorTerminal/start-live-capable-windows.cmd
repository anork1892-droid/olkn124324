@echo off
cd /d "%~dp0"
echo This starts a backend capable of signing with your dedicated wallet.
echo The dashboard starts paused in PAPER mode. LIVE requires explicit activation there.
echo Keep your wallet key file private. Do not use a primary savings wallet.
pause
docker compose -f compose.yaml -f live.compose.yaml up -d --wait
if errorlevel 1 (
 echo Could not start. Check LIVE_KEYPAIR_HOST_PATH and Docker Desktop.
 pause
 exit /b 1
)
start "" "http://localhost:8790"
pause
