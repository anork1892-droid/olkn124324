@echo off
cd /d "%~dp0"
docker compose up -d --wait
if errorlevel 1 (
  echo Startup failed. Start Docker Desktop and run install-windows.cmd first.
  pause
  exit /b 1
)
start "" "http://localhost:8790"
echo VECTOR is running. Use DASHBOARD_TOKEN from .env to sign in.
echo Close this window safely. Docker Desktop must remain running.
pause
