@echo off
cd /d "%~dp0"
if not exist .env (
 echo Run install-windows.cmd first.
 pause
 exit /b 1
)
notepad .env
