import {chromium} from 'playwright';
import {mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
const base=process.env.TEST_BASE_URL??'http://127.0.0.1:8790';
if(!process.env.DASHBOARD_TOKEN)throw Error('DASHBOARD_TOKEN is required; use the local .env file, never a literal token in a command');
const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{}),args:process.env.CI?['--no-sandbox']:[]});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(base);await page.locator('#token').fill(process.env.DASHBOARD_TOKEN);await page.getByRole('button',{name:'Unlock terminal'}).click();await page.locator('#app').waitFor({state:'visible'});
 const state=await(await page.request.get(base+'/api/state')).json();assert.equal(state.settings.mode,'paper');assert.equal(state.settings.paused,true);assert.equal(state.liveConfiguration.configured,false,'Refusing smoke controls on a live-capable backend');
 await page.locator('[data-page="Settings"]').click();assert.equal(await page.locator('[name=paperSellImpactBps]').inputValue(),state.settings.paperSellImpactBps==null?'':String(state.settings.paperSellImpactBps));const saved=page.waitForResponse(r=>r.url().endsWith('/api/settings')&&r.request().method()==='PUT');await page.getByRole('button',{name:'Save settings',exact:true}).click();assert.equal((await saved).status(),200);const updated=await(await page.request.get(base+'/api/state')).json();assert.equal(updated.settings.paperSellImpactBps,state.settings.paperSellImpactBps);assert(updated.events.every(e=>['BUY','SELL'].includes(e.data?.[0]?.side)));assert.equal((await page.request.post(base+'/api/paper/close',{data:{mint:'So11111111111111111111111111111111111111112',requestId:crypto.randomUUID()}})).status(),409);
 await page.locator('#stop').click();await page.waitForFunction(()=>document.querySelector('#running').textContent==='EMERGENCY STOP');
 assert.equal((await page.request.post(base+'/api/mode',{data:{mode:'live',wallet:'not-configured',confirmation:'not-authorized'}})).status(),400);
 for(const name of ['Overview','Live Trades','Positions','Target Wallet','Analytics','Paper Trading','Settings','Logs']){await page.locator(`[data-page="${name}"]`).click();assert.equal(await page.locator('#title').textContent(),name==='Overview'?'Trading overview':name);}
 await page.locator('[data-page="Overview"]').click();const directory=process.env.TEST_ARTIFACT_DIR??'test-results';await mkdir(directory,{recursive:true});await page.screenshot({path:directory+'/desktop.png',fullPage:true});await page.setViewportSize({width:390,height:844});await page.screenshot({path:directory+'/mobile.png',fullPage:true});
 assert.deepEqual(errors,[]);await page.request.post(base+'/api/control',{data:{action:state.settings.emergency?'stop':'pause'}});
 console.log('Browser smoke passed: login, all eight views, settings, emergency stop, rejected live activation, desktop and mobile.');
}finally{await browser.close();}
