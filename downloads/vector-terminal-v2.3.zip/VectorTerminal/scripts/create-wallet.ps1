$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Test-Path '.env')) { throw 'Run install-windows.cmd before creating a wallet.' }
$folder = Join-Path $env:USERPROFILE 'VectorWallet'
$keyFile = Join-Path $folder 'trading-keypair.json'
if (Test-Path $keyFile) { throw 'A trading key already exists in VectorWallet. It will not be overwritten.' }
New-Item -ItemType Directory -Force -Path $folder | Out-Null
Write-Host 'Creating a new dedicated wallet. No funds are transferred and live trading is not enabled.'
$script = "const fs=require('fs'); const {Keypair}=require('@solana/web3.js'); const k=Keypair.generate(); fs.writeFileSync('/wallet/trading-keypair.json',JSON.stringify(Array.from(k.secretKey)),{flag:'wx',mode:0o600}); console.log('Public wallet address: '+k.publicKey.toBase58());"
& docker compose run --rm --no-deps -T --volume "${folder}:/wallet" --entrypoint node terminal -e $script
if ($LASTEXITCODE -ne 0) { throw 'Wallet creation failed. Existing files have not been overwritten.' }
$envPath = Join-Path (Get-Location) '.env'
$text = [IO.File]::ReadAllText($envPath)
$setting = 'LIVE_KEYPAIR_HOST_PATH=' + $keyFile.Replace('\','/')
if ($text -match '(?m)^LIVE_KEYPAIR_HOST_PATH=.*$') { $text = [regex]::Replace($text, '(?m)^LIVE_KEYPAIR_HOST_PATH=.*$', $setting) }
else { $text += "`n$setting`n" }
[IO.File]::WriteAllText($envPath, $text, (New-Object Text.UTF8Encoding($false)))
Write-Host 'The private key is stored in your user profile under VectorWallet. Back it up privately.'
Write-Host 'Do not share the file. The public address above can be used to identify the wallet.'
