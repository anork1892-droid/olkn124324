$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
function New-Secret {
  $bytes = New-Object byte[] 32
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  $rng.GetBytes($bytes)
  $rng.Dispose()
  return ([BitConverter]::ToString($bytes)).Replace('-', '').ToLowerInvariant()
}
$path = Join-Path (Get-Location) '.env'
if (-not (Test-Path $path)) {
  $text = "DB_PASSWORD=$(New-Secret)`nDASHBOARD_TOKEN=$(New-Secret)`nSOLANA_RPC_URL=`nSOLANA_WS_URL=`nJUPITER_API_KEY=`n"
  [IO.File]::WriteAllText($path, $text, (New-Object Text.UTF8Encoding($false)))
  Write-Host 'Created local credentials in .env. Keep this file private.'
} else {
  $text = [IO.File]::ReadAllText($path)
  if ($text -notmatch '(?m)^DB_PASSWORD=.+') {
    [IO.File]::AppendAllText($path, "`nDB_PASSWORD=$(New-Secret)`n", (New-Object Text.UTF8Encoding($false)))
  }
}
& docker info --format '{{.OSType}}'
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop with Linux containers and retry.' }
& docker compose build
if ($LASTEXITCODE -ne 0) { throw 'Docker build failed. Check the output above.' }
Write-Host 'Install complete. Add your Solana RPC URL and Jupiter API key to .env, then run start-windows.cmd.'
Write-Host 'DASHBOARD_TOKEN in .env is your dashboard password. Never share .env or private wallet keys.'
