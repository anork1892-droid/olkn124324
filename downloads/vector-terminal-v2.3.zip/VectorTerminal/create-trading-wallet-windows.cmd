@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\create-wallet.ps1"
if errorlevel 1 echo Wallet creation did not complete. Read the error above.
pause
